# MindGuard — Launch Checklist & Setup Guide

## Stack
- **Framework**: Next.js 15 (App Router) + TypeScript
- **Styling**: Tailwind CSS (custom design system)
- **Auth + Database**: Supabase
- **Hosting**: Vercel
- **Analytics**: Plausible
- **Forms**: React Hook Form + Zod

---

## 1. Supabase Setup

### Create project
1. Go to https://supabase.com and create a new project
2. Choose a strong database password — save it securely
3. Select a region closest to your expected users (e.g., us-east-1)

### Run migrations
1. Open Supabase Dashboard → SQL Editor
2. Copy contents of `supabase/migrations/001_initial_schema.sql`
3. Run the SQL — this creates all tables, RLS policies, and triggers

### Get credentials
1. Go to Settings → API
2. Copy `Project URL` → `NEXT_PUBLIC_SUPABASE_URL`
3. Copy `anon public` key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
4. Copy `service_role` key → `SUPABASE_SERVICE_ROLE_KEY` (keep secret)

### Configure auth
1. Go to Authentication → Email Templates
2. Customize the confirmation email to match MindGuard branding
3. Go to Authentication → URL Configuration
4. Add `https://yourdomain.com/**` to allowed redirect URLs
5. Enable email confirmation (recommended for production)

---

## 2. Vercel Deployment

### Deploy
```bash
# Install Vercel CLI
npm i -g vercel

# From the mindguard directory:
vercel

# Follow prompts, then:
vercel --prod
```

### Or deploy via GitHub
1. Push code to GitHub
2. Go to https://vercel.com/new
3. Import your repository
4. Framework will be auto-detected as Next.js

### Set environment variables
In Vercel Dashboard → Project → Settings → Environment Variables, add:

| Variable | Value |
|----------|-------|
| `NEXT_PUBLIC_SUPABASE_URL` | Your Supabase project URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Your Supabase anon key |
| `SUPABASE_SERVICE_ROLE_KEY` | Your Supabase service role key |
| `NEXT_PUBLIC_APP_URL` | https://yourdomain.com |
| `NEXT_PUBLIC_PLAUSIBLE_DOMAIN` | yourdomain.com |

---

## 3. Domain Connection

### Purchase domain
- Recommended registrars: Namecheap, Cloudflare Registrar, Google Domains
- Suggested domains: mindguard.app, mindguard.io, mindguard.co

### Connect to Vercel
1. Vercel Dashboard → Project → Settings → Domains
2. Add your domain
3. Vercel will show DNS records to add

### DNS records (typical setup)
```
Type    Name    Value
A       @       76.76.21.21
CNAME   www     cname.vercel-dns.com
```

### SSL
Vercel automatically provisions SSL via Let's Encrypt — no action needed.

---

## 4. Plausible Analytics Setup

1. Sign up at https://plausible.io (starts at $9/month)
2. Add your domain
3. Set `NEXT_PUBLIC_PLAUSIBLE_DOMAIN` in Vercel environment variables
4. The script is already included in `app/layout.tsx`

**Why Plausible over GA4:**
- No cookies (GDPR compliant by default)
- No personal data collection
- Simple dashboard — no bloat
- Aligns with MindGuard's privacy-first values

---

## 5. Pre-Launch QA Checklist

### Auth
- [ ] Sign up flow works and sends confirmation email
- [ ] Login works with valid credentials
- [ ] Invalid credentials show error (not stack trace)
- [ ] Forgot password sends email
- [ ] Logout clears session
- [ ] Protected routes redirect to /login when not authenticated
- [ ] Auth pages redirect to /dashboard when already logged in

### Core features
- [ ] Daily check-in form validates all fields
- [ ] Check-in saves to database with correct user_id
- [ ] Duplicate check-in on same day updates (upsert), doesn't error
- [ ] Thought reframe saves with all fields
- [ ] Weekly reflection saves and upserts correctly
- [ ] History page loads all entries sorted newest-first
- [ ] Dashboard shows correct stats
- [ ] Insights page renders correctly with >3 entries

### UI/UX
- [ ] Site is responsive on mobile (320px-768px)
- [ ] Navigation works on mobile (hamburger menu)
- [ ] Crisis strip is visible on all marketing pages
- [ ] Crisis support page is accessible from footer and dashboard
- [ ] All external links open in new tab
- [ ] No broken links across the site

### SEO & meta
- [ ] OG tags render correctly (use https://metatags.io to test)
- [ ] Sitemap loads at /sitemap.xml
- [ ] robots.txt loads at /robots.txt
- [ ] Page titles and descriptions are set for all public pages

### Performance
- [ ] Lighthouse score > 90 on homepage
- [ ] No console errors on key pages
- [ ] Images have alt text

### Legal & safety
- [ ] Privacy Policy linked in footer and signup
- [ ] Terms of Use linked in signup checkbox
- [ ] Crisis resources visible in footer
- [ ] Safety page accessible
- [ ] Disclaimers present on auth pages and safety page

---

## 6. Post-Launch: First User Acquisition

### Week 1 — Organic channels
1. **Reddit**: Post to r/mentalhealth, r/anxiety, r/selfimprovement — share the product genuinely, not as an ad
2. **Twitter/X**: Document the build, share the "why" behind MindGuard
3. **ProductHunt**: Launch on PH for initial visibility
4. **Personal network**: Email 20 people you trust, ask for feedback

### Week 2-4 — Content SEO foundation
Start publishing content targeting:
- "daily mood tracker"
- "thought reframing exercises"
- "anxiety journaling app"
- "how to stop overthinking"
- "CBT journaling prompts"

### Paid ads (when ready)
**Campaign angle 1 — The overthinker**
Headline: "Can't stop the same thoughts? MindGuard helps you name them, reframe them, and move on."
Target: 25-45, interests in meditation/therapy/self-improvement

**Campaign angle 2 — The person not ready for therapy**
Headline: "Not ready for therapy? MindGuard is a private space to understand yourself better."
Target: 22-40, searching for mental health apps

**Campaign angle 3 — The busy professional**
Headline: "2 minutes a day. A daily check-in that actually tells you how you've been doing."
Target: 28-50, high-stress occupations

### Landing page funnel
```
Ad → /landing/[campaign-slug] → Signup → /dashboard → First Check-In
```
Create campaign-specific landing pages (same content, tracked separately).

---

## 7. Monitoring & KPIs

### Week 1 goals
- 50 signups
- 30 first check-ins completed
- 5 feedback submissions
- 0 critical errors in logs

### Month 1 goals
- 200 total signups
- 40% completing first check-in
- 20% returning after day 7
- 3-4 user interviews completed

### Key Plausible events to monitor
| Event | Healthy rate |
|-------|-------------|
| Signup Completed | >5% of visitors |
| First Checkin Completed | >60% of signups |
| D7 return | >25% |
| Reframe Completed | >40% of actives |
| Feedback Submitted | Monitor for issues |

---

## 8. Future Roadmap

### Phase 2 (Month 2-3)
- Email reminders via Resend
- PWA — add to home screen
- Improved insights with chart visualizations
- Badge push notifications

### Phase 3 (Month 4-6)
- Stripe Premium integration ($9/month)
- AI support feature (Anthropic Claude API, guardrailed)
- Personalized weekly email summaries
- Data export

### Phase 4 (Month 6+)
- iOS/Android app (React Native)
- Couples/family mode (shared check-ins)
- Therapist-view mode (optional sharing with licensed provider)
- Enterprise/workplace wellness

'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { createClient } from '@/lib/supabase/client'
import { signupSchema, type SignupInput } from '@/lib/validations/schemas'
import { analytics } from '@/lib/analytics/events'

export default function SignupPage() {
  const router = useRouter()
  const [serverError, setServerError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<SignupInput>({
    resolver: zodResolver(signupSchema),
    defaultValues: {
      agreeToTerms: undefined,
    },
  })

  analytics.signupStarted()

  const onSubmit = async (data: SignupInput) => {
    setLoading(true)
    setServerError(null)

    const supabase = createClient()
    const { error } = await supabase.auth.signUp({
      email: data.email,
      password: data.password,
      options: {
        data: {
          display_name: data.displayName || data.email.split('@')[0],
        },
        emailRedirectTo: `${window.location.origin}/dashboard`,
      },
    })

    if (error) {
      if (error.message.includes('already registered')) {
        setServerError('An account with this email already exists. Try logging in.')
      } else {
        setServerError(error.message)
      }
      setLoading(false)
      return
    }

    analytics.signupCompleted()
    setSuccess(true)
    setLoading(false)
  }

  if (success) {
    return (
      <div className="w-full max-w-sm text-center">
        <div className="bg-white rounded-2xl border border-stone-200 shadow-lg p-8">
          <div className="w-16 h-16 bg-green-50 border border-green-100 rounded-full flex items-center justify-center mx-auto mb-5">
            <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
              <path d="M6 14L11 19L22 8" stroke="#3D9B4A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <h2 className="font-display text-2xl font-medium text-stone-900 mb-2">Check your email</h2>
          <p className="text-sm text-stone-500 leading-relaxed">
            We sent a confirmation link to your email address. Click it to activate your account and begin your first check-in.
          </p>
          <p className="text-xs text-stone-400 mt-6">
            Didn&rsquo;t receive it? Check your spam folder, or{' '}
            <button className="text-blue-500 hover:underline" onClick={() => setSuccess(false)}>
              try again
            </button>.
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="w-full max-w-sm">
      <div className="bg-white rounded-2xl border border-stone-200 shadow-lg p-8">
        <div className="mb-8">
          <h1 className="font-display text-2xl font-medium text-stone-900 mb-1.5">
            Create your account
          </h1>
          <p className="text-sm text-stone-500">
            Free to start. Private by design. No credit card needed.
          </p>
        </div>

        {serverError && (
          <div className="alert-danger mb-6">{serverError}</div>
        )}

        <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-5">
          {/* Name */}
          <div>
            <label htmlFor="displayName" className="label">
              Your name <span className="text-stone-400 font-normal">(optional)</span>
            </label>
            <input
              id="displayName"
              type="text"
              autoComplete="name"
              placeholder="Alex"
              className={`input ${errors.displayName ? 'input-error' : ''}`}
              {...register('displayName')}
            />
            {errors.displayName && <p className="error-msg">{errors.displayName.message}</p>}
          </div>

          {/* Email */}
          <div>
            <label htmlFor="email" className="label">Email address</label>
            <input
              id="email"
              type="email"
              autoComplete="email"
              placeholder="you@example.com"
              className={`input ${errors.email ? 'input-error' : ''}`}
              {...register('email')}
            />
            {errors.email && <p className="error-msg">{errors.email.message}</p>}
          </div>

          {/* Password */}
          <div>
            <label htmlFor="password" className="label">Password</label>
            <input
              id="password"
              type="password"
              autoComplete="new-password"
              placeholder="8+ characters, 1 uppercase, 1 number"
              className={`input ${errors.password ? 'input-error' : ''}`}
              {...register('password')}
            />
            {errors.password && <p className="error-msg">{errors.password.message}</p>}
          </div>

          {/* Confirm password */}
          <div>
            <label htmlFor="confirmPassword" className="label">Confirm password</label>
            <input
              id="confirmPassword"
              type="password"
              autoComplete="new-password"
              placeholder="••••••••"
              className={`input ${errors.confirmPassword ? 'input-error' : ''}`}
              {...register('confirmPassword')}
            />
            {errors.confirmPassword && <p className="error-msg">{errors.confirmPassword.message}</p>}
          </div>

          {/* Terms */}
          <div>
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                className="mt-0.5 h-4 w-4 rounded border-stone-300 text-blue-500 focus:ring-blue-400 cursor-pointer"
                {...register('agreeToTerms')}
              />
              <span className="text-sm text-stone-600 leading-relaxed">
                I agree to the{' '}
                <Link href="/terms" target="_blank" className="text-blue-500 hover:underline">
                  Terms of Use
                </Link>{' '}
                and{' '}
                <Link href="/privacy" target="_blank" className="text-blue-500 hover:underline">
                  Privacy Policy
                </Link>
                . I understand MindGuard is a wellness support tool, not a medical or therapy service.
              </span>
            </label>
            {errors.agreeToTerms && (
              <p className="error-msg ml-7">{errors.agreeToTerms.message}</p>
            )}
          </div>

          <button
            type="submit"
            disabled={loading}
            className="btn-primary w-full justify-center mt-2"
          >
            {loading ? (
              <span className="flex items-center gap-2">
                <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                Creating account…
              </span>
            ) : (
              'Create Free Account'
            )}
          </button>
        </form>

        {/* Disclaimer */}
        <p className="text-xs text-stone-400 text-center mt-4 leading-relaxed">
          Not a therapy or medical service.{' '}
          <Link href="/safety" className="underline">Safety info</Link>
        </p>
      </div>

      <p className="text-center text-sm text-stone-500 mt-5">
        Already have an account?{' '}
        <Link href="/login" className="text-blue-600 font-medium hover:underline">
          Log in
        </Link>
      </p>
    </div>
  )
}

import type { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = { title: 'AI Support' }

/*
 * AI SUPPORT — ARCHITECTURE NOTES
 *
 * This page is a placeholder for a future AI wellness support feature.
 *
 * When implementing AI support:
 * 1. Create /lib/ai/client.ts — wraps the Anthropic SDK
 * 2. Create /lib/ai/systemPrompt.ts — strict wellness-only system prompt
 * 3. Create /app/api/ai-support/route.ts — streaming API route
 * 4. Replace this UI with a real chat interface
 *
 * SYSTEM PROMPT REQUIREMENTS (see /lib/ai/systemPrompt.ts.template):
 * - Role: wellness reflection guide only
 * - MUST redirect to 988/crisis resources if user mentions:
 *   suicide, self-harm, wanting to die, hurting themselves
 * - MUST NOT: diagnose, prescribe, claim to be a therapist
 * - MUST append disclaimer to every response
 * - Temperature: 0.7 (warm but grounded)
 * - Max tokens: 500 per response (prevent dependency)
 */

export default function AISupport() {
  return (
    <div className="max-w-xl mx-auto">
      <div className="mb-8">
        <h1 className="font-display text-3xl font-medium text-stone-900 mb-2">AI Support</h1>
        <p className="text-stone-400 text-sm">Guided wellness support — coming soon.</p>
      </div>

      {/* Coming soon card */}
      <div className="card p-10 text-center mb-6">
        <div className="w-16 h-16 bg-blue-50 border border-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-5">
          <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
            <path d="M14 4L4 9V15C4 21 8.5 26 14 28C19.5 26 24 21 24 15V9L14 4Z" fill="#EEF4FB" stroke="#3A7DC9" strokeWidth="1.5" />
            <path d="M10 14L13 17L18 11" stroke="#3A7DC9" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        <h2 className="font-display text-xl font-medium text-stone-900 mb-3">
          AI-guided wellness support is coming.
        </h2>
        <p className="text-sm text-stone-500 leading-relaxed max-w-sm mx-auto mb-6">
          We&rsquo;re building a carefully designed AI wellness companion. When ready, it will help with journaling prompts, thought reframing guidance, and gentle reflections.
        </p>
        <button className="btn-secondary">Join the Waitlist</button>
      </div>

      {/* Boundaries section */}
      <div className="space-y-4">
        <div className="alert-info">
          <p className="font-semibold text-blue-800 mb-2">What AI Support will help with:</p>
          <ul className="text-sm text-blue-700 space-y-1.5">
            {[
              'Journaling prompts and guided reflection questions',
              'Thought reframing assistance and gentle challenges',
              'Calming exercises and grounding techniques',
              'Summarizing your weekly patterns',
              'General wellness guidance and check-in conversation',
            ].map(item => (
              <li key={item} className="flex items-start gap-2">
                <span className="text-green-500 font-bold flex-shrink-0">✓</span>
                {item}
              </li>
            ))}
          </ul>
        </div>

        <div className="alert-warning">
          <p className="font-semibold text-amber-800 mb-2">What AI Support will never do:</p>
          <ul className="text-sm text-amber-700 space-y-1.5">
            {[
              'Diagnose mental health conditions',
              'Provide medical or psychiatric advice',
              'Act as or claim to be a therapist',
              'Replace professional mental health care',
              'Provide crisis intervention (will redirect to 988)',
            ].map(item => (
              <li key={item} className="flex items-start gap-2">
                <span className="text-red-500 font-bold flex-shrink-0">✕</span>
                {item}
              </li>
            ))}
          </ul>
        </div>

        <div className="alert-danger">
          <p className="font-semibold mb-1">If you&rsquo;re in crisis right now:</p>
          <p className="text-sm mb-3">AI support is not for emergencies. Please contact:</p>
          <Link href="/dashboard/crisis-support" className="inline-flex items-center gap-2 text-sm font-semibold text-red-700 hover:underline">
            → View crisis resources
          </Link>
        </div>
      </div>
    </div>
  )
}

'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useForm, Controller } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { createClient } from '@/lib/supabase/client'
import { checkinSchema, type CheckinInput } from '@/lib/validations/schemas'
import { todayString, moodEmoji, moodLabel } from '@/lib/utils'
import { analytics } from '@/lib/analytics/events'
import { MOOD_OPTIONS } from '@/types'
import type { Metadata } from 'next'

export default function CheckInPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const {
    register,
    handleSubmit,
    control,
    watch,
    setValue,
    formState: { errors },
  } = useForm<CheckinInput>({
    resolver: zodResolver(checkinSchema),
    defaultValues: {
      mood_score: 0,
      anxiety_level: 5,
      sleep_hours: 7,
      gratitude_note: '',
      general_notes: '',
      date: todayString(),
    },
  })

  const anxietyLevel = watch('anxiety_level')
  const sleepHours = watch('sleep_hours')
  const selectedMood = watch('mood_score')

  const onSubmit = async (data: CheckinInput) => {
    setLoading(true)
    setError(null)

    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      setError('Please log in to save your check-in.')
      setLoading(false)
      return
    }

    const { error: dbError } = await supabase
      .from('daily_checkins')
      .upsert({
        user_id: user.id,
        ...data,
      }, { onConflict: 'user_id,date' })

    if (dbError) {
      setError('Something went wrong. Please try again.')
      setLoading(false)
      return
    }

    analytics.checkinCompleted(data.mood_score)
    setSuccess(true)
    setLoading(false)
  }

  if (success) {
    return (
      <div className="max-w-lg mx-auto text-center py-16">
        <div className="w-20 h-20 bg-green-50 border border-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <svg width="36" height="36" viewBox="0 0 36 36" fill="none">
            <path d="M8 18L14 24L28 10" stroke="#3D9B4A" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        <h2 className="font-display text-3xl font-medium text-stone-900 mb-3">
          Check-in saved.
        </h2>
        <p className="text-stone-500 mb-8 leading-relaxed">
          Good work showing up for yourself today. Your entry has been saved privately.
        </p>
        <div className="flex gap-3 justify-center">
          <button onClick={() => router.push('/dashboard')} className="btn-primary">
            Back to Dashboard
          </button>
          <button onClick={() => router.push('/dashboard/reframe')} className="btn-secondary">
            Reframe a Thought →
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <h1 className="font-display text-3xl font-medium text-stone-900 mb-2">
          Daily Check-In
        </h1>
        <p className="text-stone-400 text-sm">
          A few minutes to check in with yourself. Everything here is private to you.
        </p>
      </div>

      {error && <div className="alert-danger mb-6">{error}</div>}

      <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-8">

        {/* Mood */}
        <div className="card p-6">
          <label className="label text-base mb-4 block">How are you feeling today?</label>
          <div className="grid grid-cols-5 gap-2">
            {MOOD_OPTIONS.map(option => (
              <button
                key={option.score}
                type="button"
                onClick={() => setValue('mood_score', option.score)}
                className={`flex flex-col items-center gap-1.5 py-3 px-2 rounded-xl border-2 transition-all duration-150 cursor-pointer ${
                  selectedMood === option.score
                    ? 'border-blue-400 bg-blue-50 shadow-sm'
                    : 'border-stone-200 hover:border-stone-300 hover:bg-stone-50'
                }`}
              >
                <span className="text-2xl">{option.emoji}</span>
                <span className={`text-xs font-medium text-center leading-tight ${
                  selectedMood === option.score ? 'text-blue-600' : 'text-stone-500'
                }`}>
                  {option.label}
                </span>
              </button>
            ))}
          </div>
          {errors.mood_score && (
            <p className="error-msg mt-2">{errors.mood_score.message}</p>
          )}
        </div>

        {/* Anxiety level */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-4">
            <label className="label text-base mb-0">Anxiety level</label>
            <span className="text-sm font-semibold text-blue-600">
              {anxietyLevel}/10 — {
                anxietyLevel <= 2 ? 'Very calm' :
                anxietyLevel <= 4 ? 'Mild' :
                anxietyLevel <= 6 ? 'Moderate' :
                anxietyLevel <= 8 ? 'High' : 'Very high'
              }
            </span>
          </div>
          <Controller
            name="anxiety_level"
            control={control}
            render={({ field }) => (
              <input
                type="range"
                min={1}
                max={10}
                step={1}
                {...field}
                onChange={e => field.onChange(parseInt(e.target.value))}
                style={{ '--value': `${((field.value - 1) / 9) * 100}%` } as React.CSSProperties}
                className="w-full"
              />
            )}
          />
          <div className="flex justify-between text-xs text-stone-300 mt-1">
            <span>Very calm</span>
            <span>Very anxious</span>
          </div>
        </div>

        {/* Sleep */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-4">
            <label className="label text-base mb-0">Hours of sleep</label>
            <span className="text-sm font-semibold text-blue-600">
              {sleepHours}h
            </span>
          </div>
          <Controller
            name="sleep_hours"
            control={control}
            render={({ field }) => (
              <input
                type="range"
                min={0}
                max={12}
                step={0.5}
                {...field}
                onChange={e => field.onChange(parseFloat(e.target.value))}
                style={{ '--value': `${(field.value / 12) * 100}%` } as React.CSSProperties}
                className="w-full"
              />
            )}
          />
          <div className="flex justify-between text-xs text-stone-300 mt-1">
            <span>0h</span>
            <span>12h</span>
          </div>
        </div>

        {/* Gratitude */}
        <div className="card p-6">
          <label htmlFor="gratitude_note" className="label text-base">
            One thing I&rsquo;m grateful for today
            <span className="text-stone-400 font-normal ml-1">(optional)</span>
          </label>
          <p className="text-xs text-stone-400 mb-3">Even small things count — a good coffee, a kind word, a quiet moment.</p>
          <textarea
            id="gratitude_note"
            rows={2}
            placeholder="e.g., The morning was quiet and I had time to breathe."
            className={`textarea ${errors.gratitude_note ? 'input-error' : ''}`}
            {...register('gratitude_note')}
          />
          {errors.gratitude_note && <p className="error-msg">{errors.gratitude_note.message}</p>}
        </div>

        {/* Notes */}
        <div className="card p-6">
          <label htmlFor="general_notes" className="label text-base">
            Anything else on your mind?
            <span className="text-stone-400 font-normal ml-1">(optional)</span>
          </label>
          <textarea
            id="general_notes"
            rows={3}
            placeholder="Free-write anything you want to remember about today."
            className={`textarea ${errors.general_notes ? 'input-error' : ''}`}
            {...register('general_notes')}
          />
          {errors.general_notes && <p className="error-msg">{errors.general_notes.message}</p>}
        </div>

        {/* Submit */}
        <div className="flex gap-3 pb-8">
          <button
            type="submit"
            disabled={loading}
            className="btn-primary flex-1 justify-center"
          >
            {loading ? (
              <span className="flex items-center gap-2">
                <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                Saving…
              </span>
            ) : (
              'Save Check-In'
            )}
          </button>
          <button type="button" onClick={() => router.back()} className="btn-secondary">
            Cancel
          </button>
        </div>
      </form>
    </div>
  )
}

import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Crisis Support',
  description: 'If you are in crisis or immediate danger, please use these resources now.',
}

export default function CrisisSupportPage() {
  return (
    <div className="max-w-xl mx-auto space-y-8">
      {/* Urgent header */}
      <div className="bg-red-50 border border-red-200 rounded-2xl p-8 text-center">
        <div className="text-5xl mb-4">🆘</div>
        <h1 className="font-display text-3xl font-medium text-red-900 mb-3">
          Are you in crisis right now?
        </h1>
        <p className="text-red-700 mb-6 leading-relaxed">
          MindGuard is not a crisis service. If you are in immediate danger or thinking about harming yourself, please reach out to one of these resources right now.
        </p>
        <div className="space-y-3">
          <a
            href="tel:988"
            className="block w-full bg-red-600 hover:bg-red-700 text-white font-bold py-4 px-6 rounded-xl transition-colors text-lg"
          >
            📞 Call or Text 988
            <span className="block text-sm font-normal text-red-200 mt-0.5">Suicide & Crisis Lifeline — Free, 24/7</span>
          </a>
          <a
            href="sms:741741?body=HOME"
            className="block w-full bg-stone-800 hover:bg-stone-900 text-white font-bold py-4 px-6 rounded-xl transition-colors"
          >
            💬 Text HOME to 741741
            <span className="block text-sm font-normal text-stone-400 mt-0.5">Crisis Text Line — Free, 24/7</span>
          </a>
          <a
            href="tel:911"
            className="block w-full bg-stone-700 hover:bg-stone-800 text-white font-bold py-4 px-6 rounded-xl transition-colors"
          >
            🚨 Call 911
            <span className="block text-sm font-normal text-stone-400 mt-0.5">Emergency Services — Immediate danger</span>
          </a>
        </div>
      </div>

      {/* Additional resources */}
      <div className="card p-6">
        <h2 className="font-semibold text-stone-800 mb-4">Additional Resources</h2>
        <div className="space-y-3">
          {[
            {
              name: 'NAMI Helpline',
              detail: '1-800-950-6264 · Mon–Fri 10am–10pm ET',
              sub: 'National Alliance on Mental Illness',
              href: 'https://www.nami.org/help',
            },
            {
              name: 'SAMHSA National Helpline',
              detail: '1-800-662-4357 · Free, 24/7',
              sub: 'Mental health & substance use treatment referrals',
              href: 'https://www.samhsa.gov/find-help/national-helpline',
            },
            {
              name: 'Veterans Crisis Line',
              detail: 'Call 988, then press 1 · Text 838255',
              sub: 'Confidential support for veterans',
              href: 'https://www.veteranscrisisline.net',
            },
            {
              name: 'Trans Lifeline',
              detail: '(877) 565-8860',
              sub: 'Peer support for trans people',
              href: 'https://translifeline.org',
            },
            {
              name: 'Trevor Project',
              detail: '1-866-488-7386 · Text START to 678-678',
              sub: 'Crisis intervention for LGBTQ+ youth',
              href: 'https://www.thetrevorproject.org',
            },
            {
              name: 'International Resources',
              detail: 'findahelpline.com',
              sub: 'Crisis lines worldwide',
              href: 'https://www.findahelpline.com',
            },
          ].map(r => (
            <a
              key={r.name}
              href={r.href}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-start justify-between gap-4 p-4 rounded-xl border border-stone-200 hover:bg-stone-50 transition-colors group"
            >
              <div>
                <p className="text-sm font-semibold text-stone-800 group-hover:text-blue-600 transition-colors">{r.name}</p>
                <p className="text-sm text-stone-500">{r.detail}</p>
                <p className="text-xs text-stone-400">{r.sub}</p>
              </div>
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" className="flex-shrink-0 text-stone-300 mt-1">
                <path d="M3 8H13M9 4L13 8L9 12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </a>
          ))}
        </div>
      </div>

      {/* Grounding technique */}
      <div className="bg-blue-50 border border-blue-100 rounded-2xl p-6">
        <h2 className="font-semibold text-blue-900 mb-3">If you feel overwhelmed right now</h2>
        <p className="text-sm text-blue-700 mb-4 leading-relaxed">
          Try this simple grounding exercise to help slow your nervous system while you reach out for support:
        </p>
        <div className="space-y-3">
          {[
            { num: '5', text: 'things you can see around you' },
            { num: '4', text: 'things you can touch or feel' },
            { num: '3', text: 'things you can hear right now' },
            { num: '2', text: 'things you can smell' },
            { num: '1', text: 'thing you can taste' },
          ].map(item => (
            <div key={item.num} className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-blue-200 text-blue-800 flex items-center justify-center font-bold text-sm flex-shrink-0">
                {item.num}
              </div>
              <p className="text-sm text-blue-800">{item.text}</p>
            </div>
          ))}
        </div>
        <p className="text-xs text-blue-600 mt-4">
          This technique helps anchor you to the present moment. It is not a substitute for professional support.
        </p>
      </div>

      {/* MindGuard disclaimer */}
      <div className="text-center text-xs text-stone-400 leading-relaxed pb-8">
        MindGuard is a wellness support tool and is not equipped to provide crisis intervention, emergency services, or licensed mental health care.
        The resources above are provided for informational purposes. Please reach out to a qualified professional in moments of crisis.
      </div>
    </div>
  )
}

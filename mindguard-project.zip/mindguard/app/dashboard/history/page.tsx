import { redirect } from 'next/navigation'
import type { Metadata } from 'next'
import { createClient } from '@/lib/supabase/server'
import { moodEmoji, moodLabel, formatDate, formatDateTime, weekLabel, truncate } from '@/lib/utils'

export const metadata: Metadata = { title: 'History' }

export default async function HistoryPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) redirect('/login')

  const [
    { data: checkins },
    { data: reframes },
    { data: reflections },
  ] = await Promise.all([
    supabase.from('daily_checkins').select('*').eq('user_id', user.id).order('date', { ascending: false }).limit(50),
    supabase.from('thought_reframes').select('*').eq('user_id', user.id).order('created_at', { ascending: false }).limit(30),
    supabase.from('weekly_reflections').select('*').eq('user_id', user.id).order('week_start', { ascending: false }).limit(20),
  ])

  return (
    <div className="space-y-10">
      <div>
        <h1 className="font-display text-3xl font-medium text-stone-900 mb-2">History</h1>
        <p className="text-stone-400 text-sm">Your complete wellness log — private and searchable.</p>
      </div>

      {/* Check-ins */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-semibold text-stone-800 text-lg">Daily Check-Ins</h2>
          <span className="text-xs text-stone-400">{checkins?.length ?? 0} entries</span>
        </div>

        {checkins && checkins.length > 0 ? (
          <div className="space-y-3">
            {checkins.map(checkin => (
              <div key={checkin.id} className="card p-5">
                <div className="flex items-start gap-4">
                  <span className="text-3xl mt-0.5">{moodEmoji(checkin.mood_score)}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-4 mb-2">
                      <h3 className="font-semibold text-stone-800">
                        {moodLabel(checkin.mood_score)} · {formatDate(checkin.date, 'EEEE, MMMM d')}
                      </h3>
                      <span className="text-xs text-stone-400 flex-shrink-0">{formatDate(checkin.date)}</span>
                    </div>
                    <div className="flex gap-4 text-sm text-stone-500 mb-3">
                      <span>😰 Anxiety: <strong className="text-stone-700">{checkin.anxiety_level}/10</strong></span>
                      <span>😴 Sleep: <strong className="text-stone-700">{checkin.sleep_hours}h</strong></span>
                    </div>
                    {checkin.gratitude_note && (
                      <div className="bg-green-50 border border-green-100 rounded-lg px-3 py-2 mb-2">
                        <p className="text-xs font-semibold text-green-600 mb-0.5">Gratitude</p>
                        <p className="text-sm text-green-800">{checkin.gratitude_note}</p>
                      </div>
                    )}
                    {checkin.general_notes && (
                      <p className="text-sm text-stone-500 leading-relaxed">{checkin.general_notes}</p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="card p-10 text-center">
            <p className="text-stone-400">No check-ins yet. <a href="/dashboard/check-in" className="text-blue-500 hover:underline">Start your first one →</a></p>
          </div>
        )}
      </section>

      {/* Reframes */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-semibold text-stone-800 text-lg">Thought Reframes</h2>
          <span className="text-xs text-stone-400">{reframes?.length ?? 0} entries</span>
        </div>

        {reframes && reframes.length > 0 ? (
          <div className="space-y-3">
            {reframes.map(reframe => (
              <div key={reframe.id} className="card p-5">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className="badge-stone">Intensity {reframe.intensity_level}/10</span>
                    {reframe.emotion_tags.slice(0, 3).map(tag => (
                      <span key={tag} className="badge-blue">{tag}</span>
                    ))}
                  </div>
                  <span className="text-xs text-stone-400">{formatDateTime(reframe.created_at)}</span>
                </div>
                <div className="space-y-3">
                  <div>
                    <p className="text-xs font-semibold text-stone-400 uppercase tracking-wide mb-1">Negative thought</p>
                    <p className="text-sm text-stone-700 leading-relaxed">{truncate(reframe.negative_thought, 200)}</p>
                  </div>
                  {reframe.reframed_thought && (
                    <div className="bg-blue-50 border border-blue-100 rounded-lg p-3">
                      <p className="text-xs font-semibold text-blue-600 uppercase tracking-wide mb-1">Reframe</p>
                      <p className="text-sm text-blue-800 leading-relaxed">{truncate(reframe.reframed_thought, 200)}</p>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="card p-10 text-center">
            <p className="text-stone-400">No reframes yet. <a href="/dashboard/reframe" className="text-blue-500 hover:underline">Try your first one →</a></p>
          </div>
        )}
      </section>

      {/* Reflections */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-semibold text-stone-800 text-lg">Weekly Reflections</h2>
          <span className="text-xs text-stone-400">{reflections?.length ?? 0} entries</span>
        </div>

        {reflections && reflections.length > 0 ? (
          <div className="space-y-3">
            {reflections.map(reflection => (
              <div key={reflection.id} className="card p-5">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-stone-800">Week of {weekLabel(reflection.week_start)}</h3>
                </div>
                <div className="grid sm:grid-cols-3 gap-4">
                  {reflection.biggest_challenge && (
                    <div>
                      <p className="text-xs font-semibold text-amber-600 uppercase tracking-wide mb-1">Challenge</p>
                      <p className="text-sm text-stone-600 leading-relaxed">{truncate(reflection.biggest_challenge, 120)}</p>
                    </div>
                  )}
                  {reflection.biggest_win && (
                    <div>
                      <p className="text-xs font-semibold text-green-600 uppercase tracking-wide mb-1">Win</p>
                      <p className="text-sm text-stone-600 leading-relaxed">{truncate(reflection.biggest_win, 120)}</p>
                    </div>
                  )}
                  {reflection.next_week_goal && (
                    <div>
                      <p className="text-xs font-semibold text-blue-500 uppercase tracking-wide mb-1">Intention</p>
                      <p className="text-sm text-stone-600 leading-relaxed">{truncate(reflection.next_week_goal, 120)}</p>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="card p-10 text-center">
            <p className="text-stone-400">No reflections yet. <a href="/dashboard/reflection" className="text-blue-500 hover:underline">Start your first weekly reflection →</a></p>
          </div>
        )}
      </section>
    </div>
  )
}

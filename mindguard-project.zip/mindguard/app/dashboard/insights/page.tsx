import { redirect } from 'next/navigation'
import type { Metadata } from 'next'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import { moodLabel, formatDate, average } from '@/lib/utils'

export const metadata: Metadata = { title: 'Insights' }

export default async function InsightsPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  const { data: checkins } = await supabase
    .from('daily_checkins')
    .select('*')
    .eq('user_id', user.id)
    .order('date', { ascending: false })
    .limit(30)

  const { data: reframes } = await supabase
    .from('thought_reframes')
    .select('intensity_level, emotion_tags, created_at')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })
    .limit(50)

  const hasData = (checkins?.length ?? 0) >= 3

  // Compute stats
  const avgMood = average(checkins?.map(c => c.mood_score) ?? [])
  const avgAnxiety = average(checkins?.map(c => c.anxiety_level) ?? [])
  const avgSleep = average(checkins?.map(c => c.sleep_hours) ?? [])

  // Weekly breakdown — last 4 weeks
  const weeklyData = Array.from({ length: 4 }, (_, i) => {
    const weekEnd = new Date()
    weekEnd.setDate(weekEnd.getDate() - i * 7)
    const weekStart = new Date(weekEnd)
    weekStart.setDate(weekEnd.getDate() - 6)

    const weekCheckins = (checkins ?? []).filter(c => {
      const d = new Date(c.date)
      return d >= weekStart && d <= weekEnd
    })

    return {
      label: i === 0 ? 'This week' : i === 1 ? 'Last week' : `${i * 7}d ago`,
      count: weekCheckins.length,
      avgMood: average(weekCheckins.map(c => c.mood_score)),
      avgAnxiety: average(weekCheckins.map(c => c.anxiety_level)),
      avgSleep: average(weekCheckins.map(c => c.sleep_hours)),
    }
  }).reverse()

  // Emotion frequency
  const emotionCounts: Record<string, number> = {}
  reframes?.forEach(r => {
    r.emotion_tags.forEach((tag: string) => {
      emotionCounts[tag] = (emotionCounts[tag] ?? 0) + 1
    })
  })
  const topEmotions = Object.entries(emotionCounts)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 6)

  if (!hasData) {
    return (
      <div className="max-w-xl mx-auto text-center py-20">
        <div className="text-6xl mb-5">📊</div>
        <h1 className="font-display text-3xl font-medium text-stone-900 mb-3">Insights</h1>
        <p className="text-stone-500 mb-8 leading-relaxed">
          Complete at least 3 daily check-ins to unlock your personal insights. Patterns become visible over time.
        </p>
        <Link href="/dashboard/check-in" className="btn-primary">
          Start a Check-In
        </Link>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-3xl font-medium text-stone-900 mb-2">Insights</h1>
        <p className="text-stone-400 text-sm">Patterns from your last 30 days of entries.</p>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Avg. Mood', value: avgMood ? `${avgMood}/5` : '—', sub: avgMood ? moodLabel(Math.round(avgMood)) : '', color: 'text-blue-600' },
          { label: 'Avg. Anxiety', value: avgAnxiety ? `${avgAnxiety}/10` : '—', sub: avgAnxiety && avgAnxiety <= 4 ? 'Low' : avgAnxiety && avgAnxiety <= 7 ? 'Moderate' : 'High', color: 'text-stone-700' },
          { label: 'Avg. Sleep', value: avgSleep ? `${avgSleep}h` : '—', sub: avgSleep && avgSleep >= 7 ? 'Good range' : 'Below target', color: 'text-green-600' },
        ].map(stat => (
          <div key={stat.label} className="card p-5">
            <p className="text-xs text-stone-400 uppercase tracking-wide mb-2">{stat.label}</p>
            <p className={`font-display text-2xl font-medium ${stat.color}`}>{stat.value}</p>
            <p className="text-xs text-stone-400 mt-1">{stat.sub}</p>
          </div>
        ))}
      </div>

      {/* Mood bars over last 14 days */}
      <div className="card p-6">
        <h2 className="font-semibold text-stone-800 mb-5">Mood — Last 14 Days</h2>
        <div className="flex items-end gap-1.5 h-28">
          {(checkins ?? []).slice(0, 14).reverse().map(c => {
            const heightPct = (c.mood_score / 5) * 100
            const colors = ['', 'bg-red-300', 'bg-orange-300', 'bg-amber-300', 'bg-blue-300', 'bg-green-400']
            return (
              <div key={c.id} className="flex-1 flex flex-col items-center gap-1 group relative">
                <div
                  className={`w-full rounded-t-sm transition-all ${colors[c.mood_score]}`}
                  style={{ height: `${heightPct}%` }}
                />
                {/* Tooltip */}
                <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 bg-stone-800 text-white text-xs py-1 px-2 rounded whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10">
                  {formatDate(c.date, 'MMM d')} · {moodLabel(c.mood_score)}
                </div>
              </div>
            )
          })}
        </div>
        <div className="flex justify-between text-xs text-stone-300 mt-2">
          <span>{checkins && checkins.length >= 14 ? formatDate(checkins[13].date, 'MMM d') : '14 days ago'}</span>
          <span>Today</span>
        </div>
      </div>

      {/* Weekly breakdown */}
      <div className="card p-6">
        <h2 className="font-semibold text-stone-800 mb-5">Weekly Breakdown</h2>
        <div className="space-y-4">
          {weeklyData.map(week => (
            <div key={week.label} className="flex items-center gap-4">
              <div className="w-20 text-xs text-stone-400 flex-shrink-0">{week.label}</div>
              <div className="flex-1 grid grid-cols-3 gap-3">
                {[
                  { label: 'Mood', value: week.avgMood, max: 5, color: 'bg-blue-300' },
                  { label: 'Anxiety', value: week.avgAnxiety, max: 10, color: 'bg-amber-300', invert: true },
                  { label: 'Sleep', value: week.avgSleep, max: 9, color: 'bg-green-400' },
                ].map(metric => (
                  <div key={metric.label}>
                    <div className="flex justify-between text-xs text-stone-400 mb-1">
                      <span>{metric.label}</span>
                      <span>{metric.value ?? '—'}</span>
                    </div>
                    <div className="h-1.5 bg-stone-100 rounded-full overflow-hidden">
                      {metric.value && (
                        <div
                          className={`h-full rounded-full ${metric.color}`}
                          style={{ width: `${(metric.value / metric.max) * 100}%` }}
                        />
                      )}
                    </div>
                  </div>
                ))}
              </div>
              <div className="text-xs text-stone-400 w-12 text-right flex-shrink-0">
                {week.count} day{week.count !== 1 ? 's' : ''}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Top emotions */}
      {topEmotions.length > 0 && (
        <div className="card p-6">
          <h2 className="font-semibold text-stone-800 mb-5">Most Logged Emotions</h2>
          <div className="space-y-3">
            {topEmotions.map(([emotion, count]) => {
              const maxCount = topEmotions[0][1]
              return (
                <div key={emotion} className="flex items-center gap-3">
                  <div className="w-24 text-sm text-stone-600 flex-shrink-0">{emotion}</div>
                  <div className="flex-1 h-2 bg-stone-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-300 rounded-full"
                      style={{ width: `${(count / maxCount) * 100}%` }}
                    />
                  </div>
                  <div className="text-xs text-stone-400 w-8 text-right">{count}×</div>
                </div>
              )
            })}
          </div>
          <p className="text-xs text-stone-400 mt-4">From your thought reframe entries.</p>
        </div>
      )}

      {/* Insight callout */}
      <div className="bg-blue-50 border border-blue-100 rounded-2xl p-6">
        <h3 className="font-semibold text-blue-900 mb-2">About these insights</h3>
        <p className="text-sm text-blue-700 leading-relaxed">
          These patterns are derived from your own entries and are shown only to you. They are for personal awareness only — not clinical indicators or diagnoses. If you notice persistent negative patterns, consider speaking with a mental health professional.
        </p>
      </div>
    </div>
  )
}

import { redirect } from 'next/navigation'
import Link from 'next/link'
import type { Metadata } from 'next'
import { createClient } from '@/lib/supabase/server'
import { formatDate, moodEmoji, moodLabel, calculateStreak, average, relativeDate } from '@/lib/utils'
import { BADGE_DEFINITIONS } from '@/types'

export const metadata: Metadata = { title: 'Dashboard' }

export default async function DashboardPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) redirect('/login')

  // Fetch all data in parallel
  const [
    { data: profile },
    { data: checkins },
    { data: reframes },
    { data: reflections },
    { data: badges },
  ] = await Promise.all([
    supabase.from('profiles').select('display_name').eq('id', user.id).single(),
    supabase.from('daily_checkins').select('*').eq('user_id', user.id).order('date', { ascending: false }).limit(14),
    supabase.from('thought_reframes').select('*').eq('user_id', user.id).order('created_at', { ascending: false }).limit(5),
    supabase.from('weekly_reflections').select('*').eq('user_id', user.id).order('week_start', { ascending: false }).limit(1),
    supabase.from('badge_achievements').select('*').eq('user_id', user.id),
  ])

  const displayName = profile?.display_name ?? user.email?.split('@')[0] ?? 'Friend'
  const firstName = displayName.split(' ')[0]

  const allCheckinDates = (checkins ?? []).map(c => c.date)
  const streak = calculateStreak(allCheckinDates)
  const totalCheckins = checkins?.length ?? 0

  const thisWeekCheckins = (checkins ?? []).slice(0, 7)
  const avgMood = average(thisWeekCheckins.map(c => c.mood_score))
  const avgAnxiety = average(thisWeekCheckins.map(c => c.anxiety_level))
  const avgSleep = average(thisWeekCheckins.map(c => c.sleep_hours))

  const recentCheckin = checkins?.[0] ?? null
  const isCheckedInToday = recentCheckin?.date === new Date().toISOString().split('T')[0]

  // Greeting
  const hour = new Date().getHours()
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening'

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="font-display text-3xl font-medium text-stone-900">
            {greeting}, {firstName}.
          </h1>
          <p className="text-stone-400 text-sm mt-1">
            {formatDate(new Date().toISOString().split('T')[0], 'EEEE, MMMM d')}
            {streak > 0 && (
              <span className="ml-2 text-amber-500 font-medium">
                🔥 {streak}-day streak
              </span>
            )}
          </p>
        </div>

        {/* Quick check-in CTA if not done today */}
        {!isCheckedInToday && (
          <Link href="/dashboard/check-in" className="btn-primary text-sm">
            Today&rsquo;s Check-In
          </Link>
        )}
      </div>

      {/* Check-in prompt */}
      {!isCheckedInToday && (
        <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-2xl p-6 text-white">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h2 className="font-display text-xl font-medium mb-1">
                Ready to check in?
              </h2>
              <p className="text-blue-100 text-sm leading-relaxed">
                Your daily check-in takes about two minutes and helps you stay aware of your emotional patterns.
              </p>
            </div>
            <Link
              href="/dashboard/check-in"
              className="flex-shrink-0 bg-white text-blue-600 font-semibold text-sm px-5 py-2.5 rounded-xl hover:-translate-y-0.5 hover:shadow-md transition-all"
            >
              Begin →
            </Link>
          </div>
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          {
            label: 'Check-ins this week',
            value: thisWeekCheckins.length.toString(),
            sub: 'of 7 days',
            color: 'text-blue-600',
          },
          {
            label: 'Mood average',
            value: avgMood ? `${avgMood}/5` : '—',
            sub: avgMood ? moodLabel(Math.round(avgMood)) : 'No data yet',
            color: 'text-stone-800',
          },
          {
            label: 'Sleep average',
            value: avgSleep ? `${avgSleep}h` : '—',
            sub: 'hours per night',
            color: 'text-stone-800',
          },
          {
            label: 'Total entries',
            value: totalCheckins.toString(),
            sub: streak > 0 ? `${streak}-day streak` : 'Keep it up!',
            color: 'text-green-600',
          },
        ].map(stat => (
          <div key={stat.label} className="card p-5">
            <p className="text-xs text-stone-400 uppercase tracking-wide mb-2">{stat.label}</p>
            <p className={`font-display text-2xl font-medium ${stat.color}`}>{stat.value}</p>
            <p className="text-xs text-stone-400 mt-1">{stat.sub}</p>
          </div>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Recent check-ins */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-stone-800">Recent Check-Ins</h2>
            <Link href="/dashboard/history" className="text-xs text-blue-500 hover:underline">View all</Link>
          </div>

          {checkins && checkins.length > 0 ? (
            <ul className="space-y-3">
              {checkins.slice(0, 5).map(checkin => (
                <li key={checkin.id} className="flex items-center gap-3 py-2 border-b border-stone-100 last:border-0">
                  <span className="text-2xl">{moodEmoji(checkin.mood_score)}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-stone-700">
                      {moodLabel(checkin.mood_score)} · {checkin.sleep_hours}h sleep
                    </p>
                    <p className="text-xs text-stone-400">{relativeDate(checkin.date)}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-stone-400">Anxiety</p>
                    <p className="text-sm font-medium text-stone-600">{checkin.anxiety_level}/10</p>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <div className="text-center py-8">
              <p className="text-stone-400 text-sm">No check-ins yet.</p>
              <Link href="/dashboard/check-in" className="btn-primary text-sm mt-3 inline-flex">
                Start your first one
              </Link>
            </div>
          )}
        </div>

        {/* Recent reframes + reflection */}
        <div className="space-y-5">
          {/* Last reflection */}
          <div className="card p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold text-stone-800">Weekly Reflection</h2>
              <Link href="/dashboard/reflection" className="text-xs text-blue-500 hover:underline">
                {reflections?.[0] ? 'New reflection' : 'Start →'}
              </Link>
            </div>

            {reflections?.[0] ? (
              <div className="space-y-3">
                {reflections[0].biggest_win && (
                  <div>
                    <p className="text-xs font-semibold text-green-600 uppercase tracking-wide mb-1">Win</p>
                    <p className="text-sm text-stone-600 leading-relaxed line-clamp-2">{reflections[0].biggest_win}</p>
                  </div>
                )}
                {reflections[0].next_week_goal && (
                  <div>
                    <p className="text-xs font-semibold text-blue-500 uppercase tracking-wide mb-1">This week&rsquo;s goal</p>
                    <p className="text-sm text-stone-600 leading-relaxed line-clamp-2">{reflections[0].next_week_goal}</p>
                  </div>
                )}
                <p className="text-xs text-stone-400">Week of {formatDate(reflections[0].week_start, 'MMM d')}</p>
              </div>
            ) : (
              <div className="text-center py-6">
                <p className="text-stone-400 text-sm mb-3">Take a few minutes to reflect on your week.</p>
                <Link href="/dashboard/reflection" className="btn-secondary text-sm">
                  Begin Reflection
                </Link>
              </div>
            )}
          </div>

          {/* Badges */}
          <div className="card p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold text-stone-800">Milestones</h2>
              <span className="text-xs text-stone-400">{badges?.length ?? 0} earned</span>
            </div>

            <div className="flex flex-wrap gap-2">
              {BADGE_DEFINITIONS.map(badge => {
                const earned = badges?.some(b => b.badge_slug === badge.slug)
                return (
                  <div
                    key={badge.slug}
                    title={badge.description}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                      earned
                        ? 'bg-amber-50 border-amber-200 text-amber-700'
                        : 'bg-stone-50 border-stone-200 text-stone-300'
                    }`}
                  >
                    <span>{badge.icon}</span>
                    <span>{badge.name}</span>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { createClient } from '@/lib/supabase/client'
import { reflectionSchema, type ReflectionInput } from '@/lib/validations/schemas'
import { currentWeekStart, weekLabel } from '@/lib/utils'
import { analytics } from '@/lib/analytics/events'

export default function ReflectionPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  const weekStart = currentWeekStart()

  const { register, handleSubmit, formState: { errors } } = useForm<ReflectionInput>({
    resolver: zodResolver(reflectionSchema),
    defaultValues: {
      week_start: weekStart,
      biggest_challenge: '',
      biggest_win: '',
      next_week_goal: '',
    },
  })

  const onSubmit = async (data: ReflectionInput) => {
    setLoading(true)
    setError(null)

    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      setError('Please log in.')
      setLoading(false)
      return
    }

    const { error: dbError } = await supabase
      .from('weekly_reflections')
      .upsert({
        user_id: user.id,
        ...data,
      }, { onConflict: 'user_id,week_start' })

    if (dbError) {
      setError('Something went wrong. Please try again.')
      setLoading(false)
      return
    }

    analytics.reflectionCompleted()
    setSuccess(true)
    setLoading(false)
  }

  if (success) {
    return (
      <div className="max-w-lg mx-auto text-center py-16">
        <div className="w-20 h-20 bg-green-50 border border-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <span className="text-4xl">🪞</span>
        </div>
        <h2 className="font-display text-3xl font-medium text-stone-900 mb-3">
          Reflection saved.
        </h2>
        <p className="text-stone-500 mb-8 leading-relaxed">
          Taking time to reflect each week is one of the most underrated acts of self-care. It creates perspective where daily focus creates tunnel vision.
        </p>
        <div className="flex gap-3 justify-center">
          <button onClick={() => router.push('/dashboard')} className="btn-primary">
            Back to Dashboard
          </button>
          <button onClick={() => router.push('/dashboard/history')} className="btn-secondary">
            View History
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-xl mx-auto">
      <div className="mb-8">
        <h1 className="font-display text-3xl font-medium text-stone-900 mb-2">Weekly Reflection</h1>
        <p className="text-stone-400 text-sm">
          Week of {weekLabel(weekStart)} · Takes about 5 minutes
        </p>
      </div>

      <div className="alert-info mb-8">
        <p className="text-sm leading-relaxed">
          Weekly reviews interrupt the autopilot of daily life. These three questions help you see progress that moment-to-moment focus often hides.
        </p>
      </div>

      {error && <div className="alert-danger mb-6">{error}</div>}

      <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-6">

        {/* Challenge */}
        <div className="card p-6">
          <label htmlFor="biggest_challenge" className="label text-base">
            What was your biggest challenge this week?
          </label>
          <p className="text-xs text-stone-400 mb-3">
            This can be internal (a feeling, a thought pattern) or external (a situation, a relationship).
          </p>
          <textarea
            id="biggest_challenge"
            rows={4}
            placeholder="e.g., I struggled with anxiety about a presentation at work. I found it hard to sleep the two nights before it."
            className={`textarea ${errors.biggest_challenge ? 'input-error' : ''}`}
            {...register('biggest_challenge')}
          />
          {errors.biggest_challenge && <p className="error-msg">{errors.biggest_challenge.message}</p>}
        </div>

        {/* Win */}
        <div className="card p-6">
          <label htmlFor="biggest_win" className="label text-base">
            What was your biggest win this week?
          </label>
          <p className="text-xs text-stone-400 mb-3">
            Small wins count. A moment of patience, a difficult conversation handled well, a commitment kept.
          </p>
          <textarea
            id="biggest_win"
            rows={4}
            placeholder="e.g., I gave the presentation despite the nerves. Afterward, I realized the anxiety was worse than the actual event."
            className={`textarea ${errors.biggest_win ? 'input-error' : ''}`}
            {...register('biggest_win')}
          />
          {errors.biggest_win && <p className="error-msg">{errors.biggest_win.message}</p>}
        </div>

        {/* Goal */}
        <div className="card p-6">
          <label htmlFor="next_week_goal" className="label text-base">
            What&rsquo;s one intention for next week?
          </label>
          <p className="text-xs text-stone-400 mb-3">
            Keep it specific and achievable. One clear intention is more useful than five vague ones.
          </p>
          <textarea
            id="next_week_goal"
            rows={3}
            placeholder="e.g., When I notice anxiety building, I'll pause and use the breathing exercise before reacting."
            className={`textarea ${errors.next_week_goal ? 'input-error' : ''}`}
            {...register('next_week_goal')}
          />
          {errors.next_week_goal && <p className="error-msg">{errors.next_week_goal.message}</p>}
        </div>

        <div className="flex gap-3 pb-8">
          <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center">
            {loading ? (
              <span className="flex items-center gap-2">
                <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                Saving…
              </span>
            ) : (
              'Save Reflection'
            )}
          </button>
          <button type="button" onClick={() => router.back()} className="btn-secondary">Cancel</button>
        </div>
      </form>
    </div>
  )
}

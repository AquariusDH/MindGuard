'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useForm, Controller } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { createClient } from '@/lib/supabase/client'
import { reframeSchema, type ReframeInput } from '@/lib/validations/schemas'
import { analytics } from '@/lib/analytics/events'
import { EMOTION_TAGS } from '@/types'
import { cn } from '@/lib/utils'

const REFRAME_PROMPTS = [
  'What evidence supports this thought? What evidence contradicts it?',
  'Is this thought based on a fact, or an assumption?',
  'How would you describe this situation to a trusted friend?',
  'What would you tell a loved one who had this exact thought?',
  'In 5 years, how much will this matter?',
  'Is there another way to look at this situation?',
]

export default function ReframePage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const [activePrompt, setActivePrompt] = useState<string | null>(null)

  const {
    register,
    handleSubmit,
    control,
    watch,
    setValue,
    formState: { errors },
  } = useForm<ReframeInput>({
    resolver: zodResolver(reframeSchema),
    defaultValues: {
      negative_thought: '',
      intensity_level: 5,
      emotion_tags: [],
      context_note: '',
      reframed_thought: '',
    },
  })

  const intensity = watch('intensity_level')
  const selectedTags = watch('emotion_tags')

  const toggleTag = (tag: string) => {
    const current = selectedTags ?? []
    if (current.includes(tag)) {
      setValue('emotion_tags', current.filter(t => t !== tag))
    } else if (current.length < 5) {
      setValue('emotion_tags', [...current, tag])
    }
  }

  const onSubmit = async (data: ReframeInput) => {
    setLoading(true)
    setError(null)

    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      setError('Please log in to save your reframe.')
      setLoading(false)
      return
    }

    const { error: dbError } = await supabase
      .from('thought_reframes')
      .insert({
        user_id: user.id,
        ...data,
        ai_assisted: false,
      })

    if (dbError) {
      setError('Something went wrong. Please try again.')
      setLoading(false)
      return
    }

    analytics.reframeCompleted(false)
    setSuccess(true)
    setLoading(false)
  }

  if (success) {
    return (
      <div className="max-w-lg mx-auto text-center py-16">
        <div className="w-20 h-20 bg-green-50 border border-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <svg width="36" height="36" viewBox="0 0 36 36" fill="none">
            <path d="M8 18L14 24L28 10" stroke="#3D9B4A" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        <h2 className="font-display text-3xl font-medium text-stone-900 mb-3">
          Reframe saved.
        </h2>
        <p className="text-stone-500 mb-8 leading-relaxed">
          Naming and challenging a thought is one of the most powerful things you can do for your mental wellness. Well done.
        </p>
        <div className="flex gap-3 justify-center">
          <button onClick={() => router.push('/dashboard')} className="btn-primary">
            Back to Dashboard
          </button>
          <button onClick={() => { setSuccess(false) }} className="btn-secondary">
            Reframe Another
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-xl mx-auto">
      <div className="mb-8">
        <h1 className="font-display text-3xl font-medium text-stone-900 mb-2">Thought Reframe</h1>
        <p className="text-stone-400 text-sm">
          Identify a thought that&rsquo;s weighing on you, understand it, and work toward a more balanced perspective.
        </p>
      </div>

      {/* How it works callout */}
      <div className="alert-info mb-8">
        <p className="font-semibold text-blue-800 mb-1">How this works</p>
        <p className="text-sm leading-relaxed">
          Naming a negative thought begins to reduce its power. By examining it and writing a reframed version, you practice seeing the situation more clearly. This is a skill that strengthens with repetition.
        </p>
      </div>

      {error && <div className="alert-danger mb-6">{error}</div>}

      <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-6">

        {/* The negative thought */}
        <div className="card p-6">
          <label htmlFor="negative_thought" className="label text-base">
            What thought is bothering you?
          </label>
          <p className="text-xs text-stone-400 mb-3">
            Write it exactly as it appears in your mind. Be specific.
          </p>
          <textarea
            id="negative_thought"
            rows={3}
            placeholder='e.g., "I always mess things up. Everyone at work thinks I&apos;m incompetent."'
            className={`textarea ${errors.negative_thought ? 'input-error' : ''}`}
            {...register('negative_thought')}
          />
          {errors.negative_thought && <p className="error-msg">{errors.negative_thought.message}</p>}
        </div>

        {/* Intensity */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-4">
            <label className="label text-base mb-0">How intense does this feel?</label>
            <span className="text-sm font-semibold text-blue-600">
              {intensity}/10 — {
                intensity <= 2 ? 'Mild' :
                intensity <= 4 ? 'Noticeable' :
                intensity <= 6 ? 'Significant' :
                intensity <= 8 ? 'Intense' : 'Overwhelming'
              }
            </span>
          </div>
          <Controller
            name="intensity_level"
            control={control}
            render={({ field }) => (
              <input
                type="range"
                min={1}
                max={10}
                step={1}
                {...field}
                onChange={e => field.onChange(parseInt(e.target.value))}
                style={{ '--value': `${((field.value - 1) / 9) * 100}%` } as React.CSSProperties}
                className="w-full"
              />
            )}
          />
        </div>

        {/* Emotion tags */}
        <div className="card p-6">
          <label className="label text-base">What emotions are involved?</label>
          <p className="text-xs text-stone-400 mb-4">Select up to 5 that feel most accurate.</p>
          <div className="flex flex-wrap gap-2">
            {EMOTION_TAGS.map(tag => (
              <button
                key={tag}
                type="button"
                onClick={() => toggleTag(tag)}
                className={cn(
                  'px-3 py-1.5 rounded-full text-sm font-medium border transition-all',
                  (selectedTags ?? []).includes(tag)
                    ? 'bg-blue-500 text-white border-blue-500'
                    : 'bg-white text-stone-600 border-stone-200 hover:border-stone-300'
                )}
              >
                {tag}
              </button>
            ))}
          </div>
        </div>

        {/* Context */}
        <div className="card p-6">
          <label htmlFor="context_note" className="label text-base">
            Any context?
            <span className="text-stone-400 font-normal ml-1">(optional)</span>
          </label>
          <p className="text-xs text-stone-400 mb-3">What triggered this thought? What was happening?</p>
          <textarea
            id="context_note"
            rows={2}
            placeholder="e.g., My manager gave feedback on my report and I interpreted it as criticism."
            className="textarea"
            {...register('context_note')}
          />
        </div>

        {/* Reframe */}
        <div className="card p-6">
          <label htmlFor="reframed_thought" className="label text-base">
            Now reframe it.
            <span className="text-stone-400 font-normal ml-1">(optional but powerful)</span>
          </label>

          {/* Prompts */}
          <div className="mb-4">
            <p className="text-xs text-stone-400 mb-2">Need a starting point? Try one of these prompts:</p>
            <div className="space-y-1.5">
              {REFRAME_PROMPTS.map(prompt => (
                <button
                  key={prompt}
                  type="button"
                  onClick={() => setActivePrompt(activePrompt === prompt ? null : prompt)}
                  className={cn(
                    'w-full text-left text-xs px-3 py-2 rounded-lg border transition-all',
                    activePrompt === prompt
                      ? 'bg-blue-50 border-blue-200 text-blue-700'
                      : 'bg-stone-50 border-stone-200 text-stone-500 hover:bg-stone-100'
                  )}
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>

          {activePrompt && (
            <div className="bg-blue-50 border border-blue-100 rounded-xl p-3 mb-3 text-sm text-blue-700 italic">
              Reflect on: {activePrompt}
            </div>
          )}

          <textarea
            id="reframed_thought"
            rows={4}
            placeholder="Write a more balanced, realistic perspective on the same situation. Be kind to yourself."
            className="textarea"
            {...register('reframed_thought')}
          />
        </div>

        {/* Submit */}
        <div className="flex gap-3 pb-8">
          <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center">
            {loading ? (
              <span className="flex items-center gap-2">
                <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                Saving…
              </span>
            ) : (
              'Save Reframe'
            )}
          </button>
          <button type="button" onClick={() => router.back()} className="btn-secondary">Cancel</button>
        </div>
      </form>
    </div>
  )
}

'use client'

import { useState, useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { createClient } from '@/lib/supabase/client'
import { profileSchema, type ProfileInput } from '@/lib/validations/schemas'
import { analytics } from '@/lib/analytics/events'
import { getInitials } from '@/lib/utils'

const TIMEZONES = [
  'America/New_York',
  'America/Chicago',
  'America/Denver',
  'America/Los_Angeles',
  'America/Phoenix',
  'America/Anchorage',
  'Pacific/Honolulu',
  'Europe/London',
  'Europe/Paris',
  'Europe/Berlin',
  'Asia/Tokyo',
  'Asia/Seoul',
  'Asia/Shanghai',
  'Australia/Sydney',
  'Pacific/Auckland',
]

export default function SettingsPage() {
  const [loading, setLoading] = useState(false)
  const [profileSuccess, setProfileSuccess] = useState(false)
  const [profileError, setProfileError] = useState<string | null>(null)
  const [userEmail, setUserEmail] = useState<string>('')
  const [displayName, setDisplayName] = useState<string>('')
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)
  const [deleteInput, setDeleteInput] = useState('')

  const { register, handleSubmit, reset, formState: { errors } } = useForm<ProfileInput>({
    resolver: zodResolver(profileSchema),
  })

  useEffect(() => {
    const loadProfile = async () => {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return

      setUserEmail(user.email ?? '')

      const { data: profile } = await supabase
        .from('profiles')
        .select('display_name, timezone')
        .eq('id', user.id)
        .single()

      const name = profile?.display_name ?? user.email?.split('@')[0] ?? ''
      setDisplayName(name)
      reset({
        display_name: name,
        timezone: profile?.timezone ?? Intl.DateTimeFormat().resolvedOptions().timeZone,
      })
    }

    loadProfile()
  }, [reset])

  const onSubmitProfile = async (data: ProfileInput) => {
    setLoading(true)
    setProfileError(null)
    setProfileSuccess(false)

    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return

    const { error } = await supabase
      .from('profiles')
      .update({ display_name: data.display_name, timezone: data.timezone })
      .eq('id', user.id)

    if (error) {
      setProfileError('Failed to update profile. Please try again.')
    } else {
      setDisplayName(data.display_name)
      setProfileSuccess(true)
      analytics.settingsUpdated()
      setTimeout(() => setProfileSuccess(false), 3000)
    }
    setLoading(false)
  }

  const handlePasswordReset = async () => {
    const supabase = createClient()
    const { error } = await supabase.auth.resetPasswordForEmail(userEmail, {
      redirectTo: `${window.location.origin}/auth/update-password`,
    })
    if (!error) {
      alert('Password reset email sent. Check your inbox.')
    }
  }

  return (
    <div className="max-w-xl mx-auto space-y-8">
      <div>
        <h1 className="font-display text-3xl font-medium text-stone-900 mb-2">Settings</h1>
        <p className="text-stone-400 text-sm">Manage your account and preferences.</p>
      </div>

      {/* Avatar / account overview */}
      <div className="card p-6 flex items-center gap-5">
        <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center text-xl font-bold text-blue-600 flex-shrink-0">
          {getInitials(displayName)}
        </div>
        <div>
          <p className="font-semibold text-stone-800">{displayName || 'Your Name'}</p>
          <p className="text-sm text-stone-500">{userEmail}</p>
          <p className="text-xs text-stone-400 mt-0.5">Free plan</p>
        </div>
      </div>

      {/* Profile form */}
      <div className="card p-6">
        <h2 className="font-semibold text-stone-800 mb-5">Profile</h2>

        {profileError && <div className="alert-danger mb-4">{profileError}</div>}
        {profileSuccess && <div className="alert-success mb-4">Profile updated successfully.</div>}

        <form onSubmit={handleSubmit(onSubmitProfile)} noValidate className="space-y-4">
          <div>
            <label htmlFor="display_name" className="label">Display name</label>
            <input
              id="display_name"
              type="text"
              placeholder="How should we greet you?"
              className={`input ${errors.display_name ? 'input-error' : ''}`}
              {...register('display_name')}
            />
            {errors.display_name && <p className="error-msg">{errors.display_name.message}</p>}
          </div>

          <div>
            <label htmlFor="timezone" className="label">Timezone</label>
            <select
              id="timezone"
              className="input"
              {...register('timezone')}
            >
              {TIMEZONES.map(tz => (
                <option key={tz} value={tz}>
                  {tz.replace('_', ' ')}
                </option>
              ))}
            </select>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="btn-primary"
          >
            {loading ? 'Saving…' : 'Save Changes'}
          </button>
        </form>
      </div>

      {/* Account */}
      <div className="card p-6">
        <h2 className="font-semibold text-stone-800 mb-5">Account</h2>
        <div className="space-y-4">
          <div>
            <p className="label">Email address</p>
            <p className="text-sm text-stone-500 bg-stone-50 border border-stone-200 rounded-lg px-4 py-2.5">
              {userEmail}
            </p>
          </div>

          <div>
            <p className="label">Password</p>
            <button
              type="button"
              onClick={handlePasswordReset}
              className="btn-secondary text-sm"
            >
              Send password reset email
            </button>
          </div>
        </div>
      </div>

      {/* Privacy & data */}
      <div className="card p-6">
        <h2 className="font-semibold text-stone-800 mb-2">Your Data</h2>
        <p className="text-sm text-stone-500 mb-5 leading-relaxed">
          Your wellness data belongs to you. We never sell it, share it for advertising, or use it to train AI models without your consent.
        </p>
        <div className="space-y-3">
          <div className="flex items-center justify-between py-3 border-b border-stone-100">
            <div>
              <p className="text-sm font-medium text-stone-700">Export my data</p>
              <p className="text-xs text-stone-400">Download all your entries as JSON</p>
            </div>
            <button className="btn-secondary text-xs py-1.5 px-3" disabled>
              Coming soon
            </button>
          </div>
          <div className="flex items-center justify-between py-3">
            <div>
              <p className="text-sm font-medium text-stone-700">Delete my account</p>
              <p className="text-xs text-stone-400">Permanently delete all data — cannot be undone</p>
            </div>
            <button
              className="text-xs font-medium text-red-500 hover:text-red-600 transition-colors"
              onClick={() => setShowDeleteConfirm(true)}
            >
              Delete account
            </button>
          </div>
        </div>
      </div>

      {/* Delete confirm */}
      {showDeleteConfirm && (
        <div className="card border-red-200 p-6">
          <h3 className="font-semibold text-red-800 mb-3">Confirm account deletion</h3>
          <p className="text-sm text-stone-600 mb-4 leading-relaxed">
            This will permanently delete your account and all your wellness data — check-ins, reframes, reflections, and badges. This cannot be undone.
          </p>
          <p className="text-sm text-stone-700 mb-2">
            Type <strong>DELETE</strong> to confirm:
          </p>
          <input
            type="text"
            value={deleteInput}
            onChange={e => setDeleteInput(e.target.value)}
            placeholder="DELETE"
            className="input mb-4"
          />
          <div className="flex gap-3">
            <button
              disabled={deleteInput !== 'DELETE'}
              className="btn-danger disabled:opacity-40 disabled:cursor-not-allowed text-sm"
              onClick={async () => {
                // In production: call a server action that deletes user data then calls supabase admin to delete auth user
                alert('Account deletion will be implemented via a server-side action that calls Supabase Admin API. Contact support@mindguard.app to request deletion.')
              }}
            >
              Delete My Account
            </button>
            <button
              className="btn-ghost text-sm"
              onClick={() => {
                setShowDeleteConfirm(false)
                setDeleteInput('')
              }}
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Legal links */}
      <div className="text-center text-xs text-stone-400 space-x-3 pb-8">
        <a href="/privacy" className="hover:underline">Privacy Policy</a>
        <span>·</span>
        <a href="/terms" className="hover:underline">Terms of Use</a>
        <span>·</span>
        <a href="/safety" className="hover:underline">Safety Info</a>
      </div>
    </div>
  )
}

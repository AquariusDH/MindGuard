import type { Metadata, Viewport } from 'next'
import '@/styles/globals.css'

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL ?? 'https://mindguard.app'),
  title: {
    default: 'MindGuard — Your Private Wellness Space',
    template: '%s | MindGuard',
  },
  description:
    'MindGuard is a private wellness platform for daily emotional check-ins, thought reframing, anxiety awareness, and weekly reflection. A calm, structured space for emotional clarity.',
  keywords: [
    'mental wellness',
    'daily check-in',
    'thought reframing',
    'anxiety tracker',
    'emotional awareness',
    'mood tracker',
    'mental health app',
    'gratitude journal',
    'self-reflection',
    'stress management',
    'wellness app',
    'mindfulness',
    'emotional clarity',
  ],
  authors: [{ name: 'MindGuard' }],
  creator: 'MindGuard',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://mindguard.app',
    siteName: 'MindGuard',
    title: 'MindGuard — Your Private Wellness Space',
    description:
      'Check in with yourself daily. Reframe negative thoughts. Reflect weekly. A calm, private space for emotional clarity.',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'MindGuard — Your Private Wellness Space',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'MindGuard — Your Private Wellness Space',
    description:
      'A calm, private wellness platform for daily check-ins, thought reframing, and weekly reflection.',
    images: ['/og-image.png'],
    creator: '@mindguardapp',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  manifest: '/site.webmanifest',
  icons: {
    icon: [
      { url: '/favicon.ico' },
      { url: '/icon-16.png', sizes: '16x16', type: 'image/png' },
      { url: '/icon-32.png', sizes: '32x32', type: 'image/png' },
    ],
    apple: [{ url: '/apple-touch-icon.png', sizes: '180x180' }],
  },
}

export const viewport: Viewport = {
  themeColor: '#3A7DC9',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* Plausible Analytics - privacy-first, no cookies */}
        {process.env.NEXT_PUBLIC_PLAUSIBLE_DOMAIN && (
          <script
            defer
            data-domain={process.env.NEXT_PUBLIC_PLAUSIBLE_DOMAIN}
            src="https://plausible.io/js/script.tagged-events.js"
          />
        )}
      </head>
      <body className="antialiased">
        {children}
      </body>
    </html>
  )
}

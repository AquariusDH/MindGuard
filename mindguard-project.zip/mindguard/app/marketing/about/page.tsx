import type { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'About',
  description: 'MindGuard was built out of a simple belief: that everyone deserves a private, structured space to understand themselves better.',
}

export default function AboutPage() {
  return (
    <div className="py-24 px-6">
      <div className="max-w-2xl mx-auto">
        <div className="mb-14">
          <p className="section-label">About</p>
          <h1 className="font-display text-5xl font-medium text-stone-900 tracking-tight mb-6">
            Built on a simple belief.
          </h1>
          <p className="text-xl text-stone-500 leading-relaxed">
            Everyone deserves a private, structured space to understand themselves better — without needing a therapist&rsquo;s appointment, a $50/month subscription, or a psychology degree.
          </p>
        </div>

        <div className="prose prose-stone max-w-none space-y-8 text-base leading-relaxed text-stone-600">
          <p>
            MindGuard started from a personal frustration. Traditional journaling is unstructured. Mental health apps are either bloated with features or dangerously oversimplified. Therapy, while valuable, isn&rsquo;t accessible or appropriate for every stage of every person&rsquo;s life.
          </p>

          <p>
            There was a gap: a calm, private, intelligent tool that helps people <em>build a practice</em> — not just track data. Something that reflects back what you actually feel, helps you recognize patterns, and gives you small, consistent tools to think more clearly about your own emotional life.
          </p>

          <p>
            That&rsquo;s MindGuard.
          </p>

          {/* Values */}
          <div className="grid sm:grid-cols-2 gap-4 not-prose">
            {[
              {
                title: 'Privacy first, always',
                body: 'Your wellness data is yours. We don\'t sell it. We don\'t use it for advertising. We never will.',
              },
              {
                title: 'Honest about our limits',
                body: 'MindGuard is not therapy. It\'s not a medical tool. We are clear about this — loudly and consistently.',
              },
              {
                title: 'Calm over engagement',
                body: 'We don\'t optimize for time-on-app. We optimize for usefulness. A short, honest check-in is better than 45 minutes of doom-scrolling through your own data.',
              },
              {
                title: 'Structure, not rigidity',
                body: 'A good wellness practice needs structure to stick. But it shouldn\'t feel like homework. MindGuard is flexible enough to meet you where you are.',
              },
            ].map(v => (
              <div key={v.title} className="card p-6">
                <h3 className="font-semibold text-stone-800 mb-2">{v.title}</h3>
                <p className="text-sm text-stone-500 leading-relaxed">{v.body}</p>
              </div>
            ))}
          </div>

          <h2 className="font-display text-2xl font-medium text-stone-900 mt-10">What MindGuard is not</h2>

          <p>
            We want to be direct. MindGuard is not therapy. It is not a mental health clinical tool. It will not diagnose you, treat you, or give you clinical guidance. If you are experiencing a mental health crisis, severe depression, trauma, or anything that requires professional intervention — please seek out a licensed therapist, counselor, or your local crisis line.
          </p>

          <p>
            MindGuard is for the everyday work of self-awareness. The quiet discipline of checking in. The practice of understanding yourself more clearly over time.
          </p>

          <div className="bg-blue-50 border border-blue-100 rounded-2xl p-6 not-prose">
            <p className="text-sm text-blue-700 leading-relaxed">
              If you or someone you know is in crisis, please contact the{' '}
              <strong>988 Suicide & Crisis Lifeline</strong> by calling or texting{' '}
              <a href="tel:988" className="font-bold underline">988</a>,
              or visit{' '}
              <a href="https://988lifeline.org" target="_blank" rel="noopener noreferrer" className="underline">988lifeline.org</a>.
            </p>
          </div>
        </div>

        {/* CTA */}
        <div className="mt-16 flex gap-4">
          <Link href="/signup" className="btn-primary-lg">
            Try MindGuard Free
          </Link>
          <Link href="/how-it-works" className="btn-secondary-lg">
            See How It Works
          </Link>
        </div>
      </div>
    </div>
  )
}

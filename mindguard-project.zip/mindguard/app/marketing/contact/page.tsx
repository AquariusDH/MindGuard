'use client'

import { useState } from 'react'
import type { Metadata } from 'next'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { createClient } from '@/lib/supabase/client'
import { feedbackSchema, type FeedbackInput } from '@/lib/validations/schemas'
import { analytics } from '@/lib/analytics/events'

type FeedbackType = 'bug' | 'feature' | 'general'

const FEEDBACK_TYPES: { value: FeedbackType; label: string; desc: string }[] = [
  { value: 'general', label: 'General feedback', desc: 'Thoughts, impressions, anything' },
  { value: 'feature', label: 'Feature request', desc: 'Something you wish MindGuard had' },
  { value: 'bug', label: 'Bug report', desc: 'Something that isn\'t working' },
]

export default function ContactPage() {
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [serverError, setServerError] = useState<string | null>(null)

  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<FeedbackInput>({
    resolver: zodResolver(feedbackSchema),
    defaultValues: {
      feedback_type: 'general',
      message: '',
      email: '',
    },
  })

  const selectedType = watch('feedback_type')

  const onSubmit = async (data: FeedbackInput) => {
    setLoading(true)
    setServerError(null)

    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    const { error } = await supabase.from('feedback_submissions').insert({
      user_id: user?.id ?? null,
      feedback_type: data.feedback_type,
      message: data.message,
      email: data.email ?? null,
    })

    if (error) {
      setServerError('Something went wrong. Please try again or email us directly.')
      setLoading(false)
      return
    }

    analytics.feedbackSubmitted(data.feedback_type)
    setSuccess(true)
    setLoading(false)
  }

  if (success) {
    return (
      <div className="py-20 px-6">
        <div className="max-w-sm mx-auto text-center">
          <div className="w-16 h-16 bg-green-50 border border-green-100 rounded-full flex items-center justify-center mx-auto mb-5">
            <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
              <path d="M6 14L11 19L22 8" stroke="#3D9B4A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <h2 className="font-display text-2xl font-medium text-stone-900 mb-3">Feedback received.</h2>
          <p className="text-stone-500 text-sm leading-relaxed mb-6">
            Thank you for taking the time to share your thoughts. Every piece of feedback helps us build MindGuard into something truly useful.
          </p>
          <button onClick={() => setSuccess(false)} className="btn-secondary text-sm">
            Send more feedback
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="py-20 px-6">
      <div className="max-w-xl mx-auto">
        <div className="mb-10">
          <p className="section-label">Contact & Feedback</p>
          <h1 className="font-display text-4xl font-medium text-stone-900 tracking-tight mb-4">
            We&rsquo;re listening.
          </h1>
          <p className="text-stone-500 leading-relaxed">
            MindGuard is a small, focused team building something we believe in. Your feedback directly shapes the product.
          </p>
        </div>

        {serverError && <div className="alert-danger mb-6">{serverError}</div>}

        <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-6">
          {/* Type selector */}
          <div>
            <label className="label">What kind of feedback?</label>
            <div className="grid grid-cols-3 gap-2">
              {FEEDBACK_TYPES.map(type => (
                <button
                  key={type.value}
                  type="button"
                  onClick={() => setValue('feedback_type', type.value)}
                  className={`p-3 rounded-xl border-2 text-left transition-all ${
                    selectedType === type.value
                      ? 'border-blue-400 bg-blue-50'
                      : 'border-stone-200 hover:border-stone-300 bg-white'
                  }`}
                >
                  <p className={`text-sm font-semibold ${selectedType === type.value ? 'text-blue-700' : 'text-stone-700'}`}>
                    {type.label}
                  </p>
                  <p className={`text-xs mt-0.5 ${selectedType === type.value ? 'text-blue-500' : 'text-stone-400'}`}>
                    {type.desc}
                  </p>
                </button>
              ))}
            </div>
          </div>

          {/* Message */}
          <div>
            <label htmlFor="message" className="label">Your message</label>
            <textarea
              id="message"
              rows={5}
              placeholder={
                selectedType === 'bug'
                  ? 'Describe what happened and what you expected to happen. Steps to reproduce help a lot.'
                  : selectedType === 'feature'
                  ? 'What would you like MindGuard to do that it doesn\'t do today?'
                  : 'Share your thoughts, impressions, or suggestions...'
              }
              className={`textarea ${errors.message ? 'input-error' : ''}`}
              {...register('message')}
            />
            {errors.message && <p className="error-msg">{errors.message.message}</p>}
          </div>

          {/* Email */}
          <div>
            <label htmlFor="email" className="label">
              Your email
              <span className="text-stone-400 font-normal ml-1">(optional — only if you want a reply)</span>
            </label>
            <input
              id="email"
              type="email"
              placeholder="you@example.com"
              className={`input ${errors.email ? 'input-error' : ''}`}
              {...register('email')}
            />
            {errors.email && <p className="error-msg">{errors.email.message}</p>}
          </div>

          <button
            type="submit"
            disabled={loading}
            className="btn-primary"
          >
            {loading ? 'Sending…' : 'Send Feedback'}
          </button>
        </form>

        {/* Direct email fallback */}
        <div className="mt-12 pt-8 border-t border-stone-200">
          <p className="text-sm text-stone-500">
            Prefer email?{' '}
            <a href="mailto:hello@mindguard.app" className="text-blue-500 hover:underline">
              hello@mindguard.app
            </a>
          </p>
          <p className="text-sm text-stone-500 mt-1">
            Privacy concerns?{' '}
            <a href="mailto:privacy@mindguard.app" className="text-blue-500 hover:underline">
              privacy@mindguard.app
            </a>
          </p>
        </div>
      </div>
    </div>
  )
}

import type { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'How It Works',
  description: 'MindGuard is simple by design. Check in daily, reframe negative thoughts, reflect weekly, and watch your emotional patterns become clearer over time.',
}

export default function HowItWorksPage() {
  return (
    <div className="py-20 px-6">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="text-center mb-20">
          <p className="section-label">How It Works</p>
          <h1 className="font-display text-5xl font-medium text-stone-900 tracking-tight mb-5">
            Simple by design.<br />Powerful by consistency.
          </h1>
          <p className="text-xl text-stone-500 leading-relaxed">
            MindGuard gives you four small habits that compound into real clarity over time.
          </p>
        </div>

        {/* Steps */}
        <div className="space-y-16">
          {[
            {
              step: '01',
              title: 'Daily Check-In',
              duration: '~2 minutes',
              color: 'blue',
              description: 'Each day, take two minutes to check in with yourself. Log how you feel on a simple mood scale, rate your anxiety level, note how many hours you slept, and capture one thing you\'re grateful for. You can also add any general notes about the day.',
              why: 'Consistency builds self-awareness. Even a brief daily check-in creates a data trail that reveals patterns you\'d never notice otherwise.',
              fields: ['Mood score (1–5)', 'Anxiety level (1–10)', 'Hours of sleep', 'Gratitude note', 'General notes (optional)'],
            },
            {
              step: '02',
              title: 'Thought Reframing',
              duration: '~5 minutes',
              color: 'blue',
              description: 'When a negative thought is weighing on you, write it down. Rate how intensely you feel it (1–10) and tag the emotions involved. Then — and this is the key part — work through a reframe. Write a more balanced, realistic perspective on the same situation.',
              why: 'Naming a thought begins to defuse it. Reframing it is a skill that strengthens with practice. This tool teaches you the habit of cognitive flexibility.',
              fields: ['The negative thought', 'Intensity level (1–10)', 'Emotion tags', 'Context note (optional)', 'Your reframed perspective'],
            },
            {
              step: '03',
              title: 'Weekly Reflection',
              duration: '~5 minutes',
              color: 'green',
              description: 'Once a week, take five minutes to look back. What was your biggest challenge this week? What was your biggest win — however small? What do you want to focus on next week? These three questions give structure to your growth.',
              why: 'Weekly reviews interrupt the autopilot of daily life. They help you notice progress that daily focus obscures, and they connect patterns from your check-ins into a larger narrative.',
              fields: ['Biggest challenge this week', 'Biggest win this week', 'Goal for next week'],
            },
            {
              step: '04',
              title: 'Review Your History',
              duration: 'Whenever you need it',
              color: 'green',
              description: 'Your entire log is available in the History section — sorted by newest first, readable and private. Look back at previous check-ins, reframes, and reflections to see how far you\'ve come and what patterns emerge.',
              why: 'History creates perspective. When you\'re having a hard day, reading your own past entries can remind you that hard days pass — and that you\'ve navigated them before.',
              fields: ['All past check-ins', 'All past thought reframes', 'All past weekly reflections'],
            },
          ].map((item) => (
            <div key={item.step} className="grid md:grid-cols-5 gap-8 items-start">
              <div className="md:col-span-2">
                <p className={`font-display text-6xl font-light mb-3 ${item.color === 'blue' ? 'text-blue-100' : 'text-green-100'}`}>
                  {item.step}
                </p>
                <h2 className="font-display text-2xl font-medium text-stone-900 mb-1">{item.title}</h2>
                <p className={`text-xs font-semibold tracking-wide uppercase ${item.color === 'blue' ? 'text-blue-500' : 'text-green-600'}`}>
                  {item.duration}
                </p>
              </div>
              <div className="md:col-span-3 space-y-5">
                <p className="text-base text-stone-600 leading-relaxed">{item.description}</p>
                <div className="bg-stone-50 border border-stone-200 rounded-xl p-5">
                  <p className="text-xs font-semibold text-stone-400 uppercase tracking-wide mb-3">What you log</p>
                  <ul className="space-y-1.5">
                    {item.fields.map(f => (
                      <li key={f} className="flex items-center gap-2 text-sm text-stone-600">
                        <span className="w-1 h-1 rounded-full bg-stone-300" />
                        {f}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="bg-blue-50 border border-blue-100 rounded-xl p-5">
                  <p className="text-xs font-semibold text-blue-500 uppercase tracking-wide mb-2">Why it matters</p>
                  <p className="text-sm text-blue-800 leading-relaxed">{item.why}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-20 text-center p-12 bg-gradient-to-br from-blue-600 to-blue-800 rounded-3xl text-white">
          <h2 className="font-display text-3xl font-medium mb-4">Ready to begin?</h2>
          <p className="text-white/60 mb-8 max-w-sm mx-auto">Your first check-in takes two minutes. No credit card, no commitment.</p>
          <Link href="/signup" className="inline-flex items-center justify-center bg-white text-blue-600 font-semibold px-8 py-3.5 rounded-xl hover:-translate-y-0.5 hover:shadow-lg transition-all">
            Create Your Free Account
          </Link>
        </div>
      </div>
    </div>
  )
}

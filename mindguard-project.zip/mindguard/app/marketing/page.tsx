import type { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'MindGuard — Your Private Wellness Space',
  description:
    'Check in with yourself daily. Reframe negative thoughts. Reflect weekly. A calm, private space for emotional clarity — free to start.',
}

// Hero section
function Hero() {
  return (
    <section className="relative overflow-hidden gradient-subtle py-24 md:py-32 px-6">
      {/* Ambient glow */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[900px] h-[500px] bg-blue-100/40 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-[400px] h-[300px] bg-green-100/30 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-4xl mx-auto text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 bg-white border border-blue-100 text-blue-600 text-xs font-bold tracking-widest uppercase px-4 py-1.5 rounded-full shadow-sm mb-8">
          <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse-dot" />
          Private · Secure · Free to start
        </div>

        {/* Headline */}
        <h1 className="font-display text-5xl md:text-6xl lg:text-7xl font-medium text-stone-900 leading-[1.08] tracking-tight mb-6">
          Your mind deserves<br />
          a{' '}
          <em className="font-display italic text-blue-500 not-italic" style={{ fontStyle: 'italic' }}>
            quiet place
          </em>{' '}
          to land.
        </h1>

        <p className="text-xl text-stone-500 max-w-lg mx-auto leading-relaxed mb-10">
          MindGuard is a private wellness space to check in with yourself, understand your emotions, and build healthier thinking patterns — one day at a time.
        </p>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-4">
          <Link href="/signup" className="btn-primary-lg w-full sm:w-auto">
            Start Free — No Credit Card
          </Link>
          <Link href="/how-it-works" className="btn-secondary-lg w-full sm:w-auto">
            See How It Works
          </Link>
        </div>
        <p className="text-xs text-stone-400">
          Not a therapy service. Not a medical platform. Simply a space for you.
        </p>

        {/* Dashboard mockup */}
        <div className="mt-16 max-w-3xl mx-auto">
          <div className="bg-white rounded-2xl border border-stone-200 shadow-xl overflow-hidden">
            {/* Window bar */}
            <div className="bg-stone-50 border-b border-stone-200 px-4 py-3 flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-400" />
              <div className="w-3 h-3 rounded-full bg-amber-400" />
              <div className="w-3 h-3 rounded-full bg-green-400" />
              <div className="flex-1 bg-stone-100 rounded-md px-3 py-1 ml-2 text-xs text-stone-400 font-mono">
                app.mindguard.app/dashboard
              </div>
            </div>

            {/* App UI preview */}
            <div className="grid grid-cols-5 min-h-72">
              {/* Sidebar */}
              <div className="col-span-1 bg-sage-50 border-r border-stone-200 p-4 hidden sm:block">
                <div className="space-y-1">
                  {['Dashboard', 'Check-In', 'Reframe', 'Reflect', 'History'].map((item, i) => (
                    <div
                      key={item}
                      className={`px-3 py-2 rounded-lg text-xs font-medium ${
                        i === 0
                          ? 'bg-white text-blue-600 border border-blue-100 shadow-xs'
                          : 'text-stone-400'
                      }`}
                    >
                      {item}
                    </div>
                  ))}
                </div>
              </div>

              {/* Main area */}
              <div className="col-span-5 sm:col-span-4 p-5 bg-stone-50">
                <div className="mb-4">
                  <p className="font-display text-base font-medium text-stone-800">Good morning, Alex.</p>
                  <p className="text-xs text-stone-400">Wednesday · 7-day streak 🔥</p>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-3 mb-4">
                  {[
                    { label: 'Mood avg.', value: '7.2', color: 'text-blue-500' },
                    { label: 'Sleep hrs.', value: '6.8h', color: 'text-stone-700' },
                    { label: 'Entries', value: '24', color: 'text-green-500' },
                  ].map(stat => (
                    <div key={stat.label} className="bg-white rounded-lg border border-stone-200 p-3">
                      <p className="text-xs text-stone-400 uppercase tracking-wide mb-1">{stat.label}</p>
                      <p className={`font-display text-xl font-medium ${stat.color}`}>{stat.value}</p>
                    </div>
                  ))}
                </div>

                {/* Check-in card */}
                <div className="bg-white rounded-lg border border-stone-200 p-4">
                  <p className="text-xs font-bold text-stone-500 uppercase tracking-wide mb-3">Today&rsquo;s Check-In</p>
                  <div className="flex gap-2 mb-3">
                    {['😞', '😟', '😐', '🙂', '😊'].map((emoji, i) => (
                      <div
                        key={emoji}
                        className={`flex-1 py-1.5 rounded-md border text-center text-sm cursor-pointer ${
                          i === 3
                            ? 'border-blue-300 bg-blue-50'
                            : 'border-stone-200'
                        }`}
                      >
                        {emoji}
                      </div>
                    ))}
                  </div>
                  <div className="h-1.5 bg-stone-100 rounded-full mb-2 overflow-hidden">
                    <div className="h-full w-2/5 bg-blue-300 rounded-full" />
                  </div>
                  <div className="h-1.5 bg-stone-100 rounded-full overflow-hidden">
                    <div className="h-full w-3/4 bg-green-400 rounded-full" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

// Problem section
function Problem() {
  const problems = [
    {
      num: '01',
      title: 'You overthink — and can\'t stop',
      body: 'The same thoughts loop with no outlet, no structure, and no release valve.',
    },
    {
      num: '02',
      title: 'Stress builds invisibly',
      body: 'Without a way to check in, small anxieties grow silently until they\'re hard to ignore.',
    },
    {
      num: '03',
      title: 'No consistent system',
      body: 'You want to feel better. But journaling feels tedious and apps are noisy.',
    },
    {
      num: '04',
      title: 'You deserve better than this',
      body: 'Emotional clarity shouldn\'t be complicated. You just need a private, structured space.',
    },
  ]

  return (
    <section className="bg-stone-900 py-24 px-6">
      <div className="max-w-5xl mx-auto">
        <p className="text-xs font-bold tracking-widest uppercase text-white/30 mb-4">The Problem</p>
        <h2 className="font-display text-4xl md:text-5xl font-medium text-white leading-tight tracking-tight mb-16 max-w-2xl">
          Most people carry more than they{' '}
          <em className="text-white/40">ever say out loud.</em>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-px bg-white/10 rounded-2xl overflow-hidden border border-white/10">
          {problems.map(p => (
            <div key={p.num} className="bg-white/[0.03] hover:bg-white/[0.06] transition-colors p-8">
              <p className="font-display text-4xl font-light text-white/10 mb-4">{p.num}</p>
              <h3 className="text-base font-semibold text-white/85 mb-2">{p.title}</h3>
              <p className="text-sm text-white/40 leading-relaxed">{p.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// Guide section
function Guide() {
  const principles = [
    {
      title: 'Completely private.',
      body: 'Your entries belong to you alone. We never sell, share, or analyze your data for advertising.',
    },
    {
      title: 'No pressure, no judgment.',
      body: 'Check in when you want. Skip when you need to. The space is always here.',
    },
    {
      title: 'Clear about what it is.',
      body: 'MindGuard is a wellness support tool — not therapy, not a medical service.',
    },
    {
      title: 'Designed for real life.',
      body: 'Simple enough to use every day. Structured enough to actually help.',
    },
  ]

  return (
    <section className="py-24 px-6 bg-white">
      <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-16 items-center">
        <div>
          <p className="section-label">MindGuard as Your Guide</p>
          <h2 className="section-title mb-6">
            A calm, structured space built around you.
          </h2>
          <p className="section-sub mb-6">
            MindGuard doesn&rsquo;t tell you how to feel. It gives you the structure to understand what you already do feel — and a gentle path toward greater clarity.
          </p>
          <p className="text-sm text-stone-400">
            You are the hero of this story. MindGuard is simply the guide that walks alongside you.
          </p>
        </div>

        <div className="bg-gradient-to-br from-blue-50 to-sage-50 rounded-2xl p-8 border border-blue-100">
          <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-md mb-6">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <path d="M12 2L4 6V12C4 17.5 7.5 22 12 23.5C16.5 22 20 17.5 20 12V6L12 2Z" fill="#EEF4FB" stroke="#3A7DC9" strokeWidth="1.5" />
              <path d="M9 12L11.5 14.5L15.5 10" stroke="#3A7DC9" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <ul className="space-y-0 divide-y divide-blue-100/60">
            {principles.map(p => (
              <li key={p.title} className="py-4 flex items-start gap-3">
                <div className="mt-0.5 w-5 h-5 rounded-full bg-green-50 border border-green-100 flex items-center justify-center flex-shrink-0">
                  <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
                    <path d="M2 5L4 7L8 3" stroke="#3D9B4A" strokeWidth="1.2" strokeLinecap="round" />
                  </svg>
                </div>
                <div>
                  <span className="text-sm font-semibold text-stone-800">{p.title}</span>{' '}
                  <span className="text-sm text-stone-500">{p.body}</span>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  )
}

// Plan section
function Plan() {
  const steps = [
    {
      num: '01',
      title: 'Check in daily',
      body: 'A 2-minute log of your mood, anxiety, sleep, and gratitude. Short enough to stick. Rich enough to matter.',
      accent: 'blue',
    },
    {
      num: '02',
      title: 'Log negative thoughts',
      body: 'Name the thought weighing on you. Identifying it is already a step toward loosening its grip.',
      accent: 'blue',
    },
    {
      num: '03',
      title: 'Reframe the thought',
      body: 'Use our guided structure to challenge and reframe it with a healthier perspective.',
      accent: 'green',
    },
    {
      num: '04',
      title: 'Reflect weekly',
      body: 'Look back, acknowledge progress, and set a gentle intention for the week ahead.',
      accent: 'green',
    },
  ]

  return (
    <section className="py-24 px-6 bg-sage-50">
      <div className="max-w-5xl mx-auto">
        <div className="mb-12">
          <p className="section-label">The Simple Plan</p>
          <h2 className="section-title mb-4">Four steps toward more clarity.</h2>
          <p className="section-sub">You don&rsquo;t need a complex system. Just a consistent practice.</p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {steps.map(step => (
            <div
              key={step.num}
              className="card-hover p-6"
            >
              <p className={`font-display text-4xl font-light mb-4 ${step.accent === 'blue' ? 'text-blue-100' : 'text-green-100'}`}>
                {step.num}
              </p>
              <h3 className="text-base font-semibold text-stone-800 mb-2">{step.title}</h3>
              <p className="text-sm text-stone-500 leading-relaxed">{step.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// Features section
function Features() {
  const features = [
    {
      icon: (
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <rect x="3" y="3" width="14" height="14" rx="3" stroke="#3A7DC9" strokeWidth="1.5" />
          <path d="M7 10H13M7 7H10" stroke="#3A7DC9" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      ),
      bg: 'bg-blue-50 border-blue-100',
      title: 'Daily Check-In',
      body: 'Log mood, anxiety, sleep, and a moment of gratitude. Takes about two minutes.',
    },
    {
      icon: (
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <path d="M5 15L10 5L15 15" stroke="#3A7DC9" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M7.5 11H12.5" stroke="#3A7DC9" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      ),
      bg: 'bg-blue-50 border-blue-100',
      title: 'Thought Reframe',
      body: 'Name the negative thought, rate its intensity, and find a more balanced perspective.',
    },
    {
      icon: (
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <path d="M4 6H16M4 10H12M4 14H8" stroke="#3D9B4A" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      ),
      bg: 'bg-green-50 border-green-100',
      title: 'Weekly Reflection',
      body: 'Review your biggest challenge, celebrate your wins, and set an intention for next week.',
    },
    {
      icon: (
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <path d="M5 15L8 9L11 12L14 6" stroke="#3D9B4A" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      ),
      bg: 'bg-green-50 border-green-100',
      title: 'Entry History',
      body: 'Every check-in is saved privately. See patterns, notice growth, and track your journey.',
    },
    {
      icon: (
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <path d="M10 14C12.2 14 14 12.2 14 10C14 7.8 12.2 6 10 6C7.8 6 6 7.8 6 10C6 12.2 7.8 14 10 14Z" stroke="#87857F" strokeWidth="1.5" />
          <path d="M10 3V5M10 15V17M3 10H5M15 10H17" stroke="#87857F" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      ),
      bg: 'bg-stone-100 border-stone-200',
      title: 'Gratitude Practice',
      body: 'Each check-in includes a space for one small thing you\'re grateful for. Small shifts matter.',
    },
    {
      icon: (
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <path d="M10 3L12 8H17L13 11L14.5 16L10 13L5.5 16L7 11L3 8H8L10 3Z" stroke="#87857F" strokeWidth="1.5" strokeLinejoin="round" />
        </svg>
      ),
      bg: 'bg-stone-100 border-stone-200',
      title: 'Milestones',
      body: 'Acknowledge consistency with milestone markers — not gamification, just recognition.',
    },
  ]

  return (
    <section className="py-24 px-6 bg-white">
      <div className="max-w-5xl mx-auto">
        <div className="mb-12">
          <p className="section-label">Features</p>
          <h2 className="section-title mb-4">Everything you need, nothing you don&rsquo;t.</h2>
          <p className="section-sub">A focused, clean set of tools — no bloat, no noise.</p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-px bg-stone-200 rounded-2xl overflow-hidden border border-stone-200">
          {features.map(f => (
            <div key={f.title} className="bg-white hover:bg-stone-50 transition-colors p-7">
              <div className={`w-11 h-11 rounded-xl flex items-center justify-center border mb-4 ${f.bg}`}>
                {f.icon}
              </div>
              <h3 className="text-base font-semibold text-stone-800 mb-2">{f.title}</h3>
              <p className="text-sm text-stone-500 leading-relaxed">{f.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// Trust/Safety section
function Trust() {
  const items = [
    {
      badge: '🔒 Private by design',
      title: 'Your data stays yours',
      body: "We don't sell your wellness data. We don't use it for advertising. Your entries are encrypted and private.",
    },
    {
      badge: '⚖️ Honest boundaries',
      title: "We're clear about what we are",
      body: 'MindGuard is a wellness support tool — not a licensed mental health platform, not a therapy replacement.',
    },
    {
      badge: '❤️ Crisis-aware',
      title: 'Emergency resources always visible',
      body: "If you're in crisis, we direct you to proper support — 988 Lifeline, emergency services — every time.",
    },
    {
      badge: '🌿 No dependency design',
      title: 'Designed for your independence',
      body: 'MindGuard supports real-life coping, not engagement loops. We want you to feel better, not stay longer.',
    },
  ]

  return (
    <section className="py-20 px-6 bg-blue-50 border-y border-blue-100">
      <div className="max-w-5xl mx-auto">
        <p className="section-label">Privacy & Safety</p>
        <h2 className="section-title mb-12 max-w-xl">Built with your trust as the foundation.</h2>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {items.map(item => (
            <div key={item.title}>
              <div className="badge-blue mb-4">{item.badge}</div>
              <h3 className="text-base font-semibold text-stone-800 mb-2">{item.title}</h3>
              <p className="text-sm text-stone-600 leading-relaxed">{item.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// Outcome section
function Outcome() {
  return (
    <section className="py-24 px-6 bg-white">
      <div className="max-w-5xl mx-auto">
        <p className="section-label">The Transformation</p>
        <h2 className="section-title mb-4">What clarity actually feels like.</h2>
        <p className="section-sub mb-12">Two possible futures. One small daily habit separates them.</p>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Success */}
          <div className="bg-green-50 border border-green-100 rounded-2xl p-8">
            <div className="inline-block bg-green-100 text-green-700 text-xs font-bold tracking-widest uppercase px-3 py-1 rounded-md mb-6">
              With MindGuard
            </div>
            <ul className="space-y-4">
              {[
                'You understand your emotional patterns instead of being controlled by them',
                'Negative thoughts lose their power because you can name and challenge them',
                'You start each week with intention instead of dread',
                'A consistent practice replaces the chaos of unprocessed emotion',
                'You feel grounded, even on hard days',
              ].map(item => (
                <li key={item} className="flex items-start gap-3 text-sm text-stone-700 leading-relaxed">
                  <span className="mt-1.5 w-2 h-2 rounded-full bg-green-400 flex-shrink-0" />
                  {item}
                </li>
              ))}
            </ul>
          </div>

          {/* Failure */}
          <div className="bg-stone-100 border border-stone-200 rounded-2xl p-8">
            <div className="inline-block bg-stone-200 text-stone-600 text-xs font-bold tracking-widest uppercase px-3 py-1 rounded-md mb-6">
              Without it
            </div>
            <ul className="space-y-4">
              {[
                'The same thought loops repeat with no resolution',
                'Stress builds invisibly until it becomes overwhelming',
                'Emotional patterns stay hidden, hard to recognize or change',
                'No structure means good intentions rarely stick',
                'You keep waiting to feel better — but nothing changes',
              ].map(item => (
                <li key={item} className="flex items-start gap-3 text-sm text-stone-500 leading-relaxed">
                  <span className="mt-1.5 w-2 h-2 rounded-full bg-stone-400 flex-shrink-0" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}

// Pricing preview
function Pricing() {
  return (
    <section className="py-24 px-6 bg-sage-50">
      <div className="max-w-3xl mx-auto text-center">
        <p className="section-label">Pricing</p>
        <h2 className="section-title mb-4">Start free. Upgrade when it feels right.</h2>
        <p className="section-sub mx-auto mb-12">Emotional wellness shouldn&rsquo;t be locked behind a paywall. The core tools are always free.</p>

        <div className="grid sm:grid-cols-2 gap-5 text-left">
          {/* Free */}
          <div className="card p-8">
            <div className="badge-green mb-4">Free</div>
            <div className="font-display text-4xl font-medium text-stone-900 mb-1">$0</div>
            <p className="text-sm text-stone-400 mb-6 pb-6 border-b border-stone-100">Everything you need to build a real wellness practice.</p>
            <ul className="space-y-3 mb-8">
              {['Daily check-ins', 'Thought reframing', 'Weekly reflections', 'Entry history', 'Milestones & streaks'].map(f => (
                <li key={f} className="flex items-center gap-2.5 text-sm text-stone-700">
                  <span className="w-4 h-4 rounded-full bg-green-50 border border-green-100 flex items-center justify-center flex-shrink-0">
                    <svg width="8" height="8" viewBox="0 0 8 8" fill="none"><path d="M1 4L3 6L7 2" stroke="#3D9B4A" strokeWidth="1.2" strokeLinecap="round" /></svg>
                  </span>
                  {f}
                </li>
              ))}
            </ul>
            <Link href="/signup" className="btn-secondary w-full justify-center">Create Free Account</Link>
          </div>

          {/* Premium */}
          <div className="card p-8 border-2 border-blue-200 relative">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-blue-500 text-white text-xs font-bold px-3 py-1 rounded-full">Coming Soon</div>
            <div className="badge-blue mb-4">Premium</div>
            <div className="font-display text-4xl font-medium text-stone-900 mb-1">$9<span className="text-base font-body text-stone-400 font-normal"> / mo</span></div>
            <p className="text-sm text-stone-400 mb-6 pb-6 border-b border-stone-100">For those ready to go deeper with their emotional wellness.</p>
            <ul className="space-y-3 mb-8">
              {['Everything in Free', 'AI-guided reflections & prompts', 'Advanced mood insights', 'Personalized weekly summaries', 'Full history & data export'].map(f => (
                <li key={f} className="flex items-center gap-2.5 text-sm text-stone-700">
                  <span className="w-4 h-4 rounded-full bg-green-50 border border-green-100 flex items-center justify-center flex-shrink-0">
                    <svg width="8" height="8" viewBox="0 0 8 8" fill="none"><path d="M1 4L3 6L7 2" stroke="#3D9B4A" strokeWidth="1.2" strokeLinecap="round" /></svg>
                  </span>
                  {f}
                </li>
              ))}
            </ul>
            <button className="btn-primary w-full justify-center">Join Waitlist</button>
          </div>
        </div>
      </div>
    </section>
  )
}

// Final CTA
function FinalCTA() {
  return (
    <section className="py-28 px-6 bg-gradient-to-br from-blue-600 to-blue-900 text-white relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-white/5 rounded-full blur-3xl" />
      </div>
      <div className="relative max-w-xl mx-auto text-center">
        <h2 className="font-display text-4xl md:text-5xl font-medium text-white leading-tight tracking-tight mb-5">
          Ready to understand<br />yourself better?
        </h2>
        <p className="text-lg text-white/60 leading-relaxed mb-8">
          Your first check-in takes two minutes. No commitment, no credit card. Just a calmer, clearer starting point.
        </p>
        <Link
          href="/signup"
          className="inline-flex items-center justify-center bg-white text-blue-600 font-semibold text-base px-8 py-4 rounded-xl shadow-lg hover:-translate-y-0.5 hover:shadow-xl transition-all duration-200"
        >
          Begin Your First Check-In →
        </Link>
        <p className="mt-4 text-xs text-white/30">Free to start. No medical claims. No therapy replacement.</p>
      </div>
    </section>
  )
}

export default function HomePage() {
  return (
    <>
      <Hero />
      <Problem />
      <Guide />
      <Plan />
      <Features />
      <Trust />
      <Outcome />
      <Pricing />
      <FinalCTA />
    </>
  )
}

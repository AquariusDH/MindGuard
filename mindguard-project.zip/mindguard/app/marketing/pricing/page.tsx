import type { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'Pricing',
  description: 'MindGuard is free to start. The core wellness tools — daily check-ins, thought reframing, and weekly reflections — are always free.',
}

export default function PricingPage() {
  return (
    <div className="py-24 px-6">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="section-label">Pricing</p>
          <h1 className="font-display text-5xl font-medium text-stone-900 tracking-tight mb-5">
            Honest, simple pricing.
          </h1>
          <p className="text-xl text-stone-500 max-w-md mx-auto leading-relaxed">
            Emotional wellness shouldn&rsquo;t be locked behind a paywall. The core tools are free — always.
          </p>
        </div>

        {/* Plans */}
        <div className="grid md:grid-cols-2 gap-6 mb-16">
          {/* Free */}
          <div className="card-lg p-8">
            <div className="badge-green mb-5">Free — Forever</div>
            <div className="font-display text-5xl font-medium text-stone-900 mb-1">$0</div>
            <p className="text-stone-400 text-sm mb-6 pb-6 border-b border-stone-100">
              No time limits. No feature restrictions on the core tools.
            </p>

            <ul className="space-y-3 mb-8">
              {[
                'Unlimited daily check-ins',
                'Mood, anxiety & sleep tracking',
                'Gratitude logging',
                'Thought reframing',
                'Weekly reflections',
                'Full entry history',
                'Milestone badges',
                'Streak tracking',
                'Private & encrypted',
              ].map(f => (
                <li key={f} className="flex items-center gap-3 text-sm text-stone-700">
                  <span className="w-4 h-4 rounded-full bg-green-50 border border-green-100 flex items-center justify-center flex-shrink-0">
                    <svg width="8" height="8" viewBox="0 0 8 8" fill="none">
                      <path d="M1 4L3 6L7 2" stroke="#3D9B4A" strokeWidth="1.2" strokeLinecap="round" />
                    </svg>
                  </span>
                  {f}
                </li>
              ))}
            </ul>

            <Link href="/signup" className="btn-secondary w-full justify-center">
              Create Free Account
            </Link>
          </div>

          {/* Premium */}
          <div className="card-lg p-8 border-2 border-blue-200 relative">
            <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-blue-500 text-white text-xs font-bold px-4 py-1.5 rounded-full">
              Coming Soon
            </div>
            <div className="badge-blue mb-5">Premium</div>
            <div className="font-display text-5xl font-medium text-stone-900 mb-1">
              $9
              <span className="font-body text-lg text-stone-400 font-normal"> / month</span>
            </div>
            <p className="text-stone-400 text-sm mb-6 pb-6 border-b border-stone-100">
              For those ready to go deeper with their emotional wellness practice.
            </p>

            <ul className="space-y-3 mb-8">
              {[
                'Everything in Free',
                'AI-guided reflections & journaling prompts',
                'AI-assisted thought reframing',
                'Advanced mood & pattern insights',
                'Personalized weekly summary reports',
                'Full data export (JSON)',
                'Priority support',
              ].map(f => (
                <li key={f} className="flex items-center gap-3 text-sm text-stone-700">
                  <span className="w-4 h-4 rounded-full bg-blue-50 border border-blue-100 flex items-center justify-center flex-shrink-0">
                    <svg width="8" height="8" viewBox="0 0 8 8" fill="none">
                      <path d="M1 4L3 6L7 2" stroke="#3A7DC9" strokeWidth="1.2" strokeLinecap="round" />
                    </svg>
                  </span>
                  {f}
                </li>
              ))}
            </ul>

            <button className="btn-primary w-full justify-center">
              Join the Waitlist
            </button>
            <p className="text-xs text-stone-400 text-center mt-3">
              Be first to know when Premium launches.
            </p>
          </div>
        </div>

        {/* FAQ */}
        <div className="space-y-5">
          <h2 className="font-display text-2xl font-medium text-stone-900 mb-6">Frequently asked questions</h2>

          {[
            {
              q: 'Is the free plan really free forever?',
              a: 'Yes. The core MindGuard tools — daily check-ins, thought reframing, weekly reflections, history, and milestones — will always be free. We believe basic emotional wellness support should be accessible to everyone.',
            },
            {
              q: 'Will my data be used to train AI?',
              a: 'No. We do not and will not use your personal wellness entries to train AI models without explicit opt-in consent. Your data belongs to you.',
            },
            {
              q: 'Can I cancel Premium at any time?',
              a: 'Yes. Premium will be month-to-month with no long-term commitment. Cancel anytime from your account settings.',
            },
            {
              q: 'What happens to my data if I cancel?',
              a: 'All your data remains in your account on the Free plan. Nothing is deleted when you downgrade. If you close your account entirely, you can export your data first.',
            },
            {
              q: 'Is MindGuard HIPAA compliant?',
              a: 'MindGuard is not a medical platform and does not claim HIPAA compliance. Your wellness data is stored securely and privately, but this is not a medical records system. Please do not use MindGuard as a substitute for medical records.',
            },
          ].map(faq => (
            <div key={faq.q} className="card p-6">
              <h3 className="font-semibold text-stone-800 mb-2">{faq.q}</h3>
              <p className="text-sm text-stone-500 leading-relaxed">{faq.a}</p>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-16 text-center">
          <p className="text-stone-500 mb-5">Ready to begin?</p>
          <Link href="/signup" className="btn-primary-lg">
            Start Free — No Credit Card
          </Link>
        </div>
      </div>
    </div>
  )
}

import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Privacy Policy',
  description: 'MindGuard takes your privacy seriously. Read how we collect, store, and protect your wellness data.',
}

export default function PrivacyPage() {
  const lastUpdated = 'January 1, 2025'

  return (
    <div className="py-20 px-6">
      <div className="max-w-2xl mx-auto">
        <div className="mb-12">
          <p className="section-label">Legal</p>
          <h1 className="font-display text-4xl font-medium text-stone-900 tracking-tight mb-4">
            Privacy Policy
          </h1>
          <p className="text-sm text-stone-400">Last updated: {lastUpdated}</p>
        </div>

        <div className="alert-info mb-8">
          <strong>Short version:</strong> Your wellness data is private. We don&rsquo;t sell it, share it for advertising, or give it to third parties without your consent. You own your data.
        </div>

        <div className="prose prose-stone max-w-none space-y-10 text-sm leading-relaxed text-stone-600">

          <section>
            <h2 className="font-display text-xl font-medium text-stone-900 mb-3">1. Information We Collect</h2>
            <p><strong className="text-stone-700">Account information:</strong> When you create an account, we collect your email address and a display name (optional). Passwords are hashed — we never see them in plain text.</p>
            <p className="mt-3"><strong className="text-stone-700">Wellness content:</strong> The check-ins, thought reframes, weekly reflections, and notes you enter in MindGuard. This is stored securely in our database and associated with your account.</p>
            <p className="mt-3"><strong className="text-stone-700">Usage data:</strong> We use Plausible Analytics, a privacy-focused analytics service. Plausible does not use cookies and does not collect personal data. It measures aggregate page visits and feature usage only.</p>
            <p className="mt-3"><strong className="text-stone-700">Support communications:</strong> If you contact us or submit feedback, we collect that message and your email if provided.</p>
          </section>

          <section>
            <h2 className="font-display text-xl font-medium text-stone-900 mb-3">2. How We Use Your Data</h2>
            <ul className="space-y-2 list-none">
              {[
                'To provide and operate MindGuard for you',
                'To display your own wellness history and insights back to you',
                'To maintain and improve the product',
                'To respond to support requests',
                'To send transactional emails (account confirmation, password reset) — nothing promotional without explicit opt-in',
              ].map(item => (
                <li key={item} className="flex items-start gap-2">
                  <span className="text-blue-400 mt-0.5">·</span>
                  {item}
                </li>
              ))}
            </ul>
          </section>

          <section>
            <h2 className="font-display text-xl font-medium text-stone-900 mb-3">3. What We Never Do</h2>
            <div className="bg-stone-50 rounded-xl p-5 space-y-2">
              {[
                'Sell your personal data or wellness content to third parties',
                'Share your data for advertising purposes',
                'Use your wellness entries to train AI models without explicit consent',
                'Share identifiable data with employers, insurers, or other organizations',
                'Contact you with unsolicited marketing without your opt-in',
              ].map(item => (
                <div key={item} className="flex items-start gap-2 text-sm text-stone-600">
                  <span className="text-red-400 font-bold flex-shrink-0">✕</span>
                  {item}
                </div>
              ))}
            </div>
          </section>

          <section>
            <h2 className="font-display text-xl font-medium text-stone-900 mb-3">4. Data Storage & Security</h2>
            <p>Your data is stored in a Supabase PostgreSQL database hosted on AWS infrastructure. We use Row Level Security (RLS) policies to ensure that users can only access their own data — not other users&rsquo;.</p>
            <p className="mt-3">All data is encrypted in transit using TLS/HTTPS. Passwords are hashed using Supabase&rsquo;s authentication system (bcrypt).</p>
            <p className="mt-3">We follow security best practices for environment variable management, API key rotation, and access control. However, no system is 100% secure — if you believe your account has been compromised, contact us immediately.</p>
          </section>

          <section>
            <h2 className="font-display text-xl font-medium text-stone-900 mb-3">5. Third-Party Services</h2>
            <div className="space-y-3">
              {[
                { name: 'Supabase', purpose: 'Authentication and database hosting', link: 'https://supabase.com/privacy' },
                { name: 'Vercel', purpose: 'Website hosting and deployment', link: 'https://vercel.com/legal/privacy-policy' },
                { name: 'Plausible Analytics', purpose: 'Privacy-first analytics (no cookies, no personal data)', link: 'https://plausible.io/privacy' },
              ].map(s => (
                <div key={s.name} className="card p-4">
                  <p className="text-sm font-semibold text-stone-700">{s.name}</p>
                  <p className="text-xs text-stone-500">{s.purpose} · <a href={s.link} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">Privacy policy</a></p>
                </div>
              ))}
            </div>
          </section>

          <section>
            <h2 className="font-display text-xl font-medium text-stone-900 mb-3">6. Your Rights</h2>
            <p>You have the right to:</p>
            <ul className="mt-3 space-y-2 list-none">
              {[
                'Access all your personal data and wellness entries',
                'Correct inaccurate information in your profile',
                'Export your wellness data (available in account settings)',
                'Delete your account and all associated data',
                'Opt out of any non-essential communications',
              ].map(item => (
                <li key={item} className="flex items-start gap-2">
                  <span className="text-green-500 mt-0.5">✓</span>
                  {item}
                </li>
              ))}
            </ul>
            <p className="mt-4">To exercise any of these rights, visit your account Settings or contact us at <a href="mailto:privacy@mindguard.app" className="text-blue-500 hover:underline">privacy@mindguard.app</a>.</p>
          </section>

          <section>
            <h2 className="font-display text-xl font-medium text-stone-900 mb-3">7. Children&rsquo;s Privacy</h2>
            <p>MindGuard is intended for adults 18 years of age and older. We do not knowingly collect personal information from children under 13. If you believe a child under 13 has created an account, please contact us and we will promptly delete the account.</p>
          </section>

          <section>
            <h2 className="font-display text-xl font-medium text-stone-900 mb-3">8. Changes to This Policy</h2>
            <p>We may update this Privacy Policy from time to time. Material changes will be communicated via email or a prominent notice on the site. Continued use of MindGuard after a policy update constitutes acceptance of the new policy.</p>
          </section>

          <section>
            <h2 className="font-display text-xl font-medium text-stone-900 mb-3">9. Contact</h2>
            <p>Questions about this Privacy Policy? Contact us:</p>
            <div className="card p-5 mt-4">
              <p className="text-sm font-semibold text-stone-700">MindGuard Privacy Team</p>
              <p className="text-sm text-stone-500">Email: <a href="mailto:privacy@mindguard.app" className="text-blue-500 hover:underline">privacy@mindguard.app</a></p>
            </div>
          </section>
        </div>
      </div>
    </div>
  )
}

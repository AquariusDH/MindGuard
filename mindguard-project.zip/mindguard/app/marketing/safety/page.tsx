import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Safety & Disclaimer',
  description: 'MindGuard is a wellness support tool, not a licensed mental health service. Read our safety information and crisis resources here.',
}

export default function SafetyPage() {
  return (
    <div className="py-20 px-6">
      <div className="max-w-2xl mx-auto">
        {/* Crisis banner - prominent */}
        <div className="bg-red-50 border border-red-200 rounded-2xl p-6 mb-12 text-center">
          <div className="text-3xl mb-3">🆘</div>
          <h2 className="font-display text-xl font-medium text-red-900 mb-2">In immediate danger?</h2>
          <p className="text-sm text-red-700 mb-4">
            MindGuard is not an emergency service. If you are in crisis or danger, please reach out immediately:
          </p>
          <div className="space-y-2">
            <a href="tel:988" className="block bg-red-600 text-white font-semibold py-3 px-6 rounded-xl hover:bg-red-700 transition-colors">
              Call or Text 988 — Suicide & Crisis Lifeline
            </a>
            <a href="tel:911" className="block bg-stone-800 text-white font-semibold py-3 px-6 rounded-xl hover:bg-stone-900 transition-colors">
              Call 911 — Emergency Services
            </a>
          </div>
          <p className="text-xs text-red-500 mt-4">
            International resources available at{' '}
            <a href="https://www.findahelpline.com" target="_blank" rel="noopener noreferrer" className="underline">
              findahelpline.com
            </a>
          </p>
        </div>

        {/* Header */}
        <div className="mb-12">
          <p className="section-label">Safety & Disclaimer</p>
          <h1 className="font-display text-4xl font-medium text-stone-900 tracking-tight mb-4">
            Honesty is our foundation.
          </h1>
          <p className="text-lg text-stone-500 leading-relaxed">
            We built MindGuard with care. That means being completely honest about what it is — and what it isn&rsquo;t.
          </p>
        </div>

        <div className="prose prose-stone max-w-none space-y-10">
          {/* What MindGuard is */}
          <section>
            <h2 className="font-display text-2xl font-medium text-stone-900 mb-4">What MindGuard Is</h2>
            <div className="card p-6 space-y-3">
              {[
                'A private wellness support tool',
                'A daily emotional check-in system',
                'A structured space for thought reframing',
                'A personal reflection and journaling platform',
                'A habit-building tool for emotional awareness',
              ].map(item => (
                <div key={item} className="flex items-start gap-3 text-sm text-stone-700">
                  <span className="w-5 h-5 rounded-full bg-green-50 border border-green-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <svg width="10" height="10" viewBox="0 0 10 10" fill="none"><path d="M2 5L4 7L8 3" stroke="#3D9B4A" strokeWidth="1.2" strokeLinecap="round" /></svg>
                  </span>
                  {item}
                </div>
              ))}
            </div>
          </section>

          {/* What it is NOT */}
          <section>
            <h2 className="font-display text-2xl font-medium text-stone-900 mb-4">What MindGuard Is NOT</h2>
            <div className="card p-6 space-y-3">
              {[
                'A licensed mental health service',
                'A replacement for therapy or professional counseling',
                'A medical diagnosis tool',
                'A crisis intervention service',
                'An emergency support system',
                'A psychiatric or clinical platform',
                'A substitute for professional medical advice',
              ].map(item => (
                <div key={item} className="flex items-start gap-3 text-sm text-stone-700">
                  <span className="w-5 h-5 rounded-full bg-red-50 border border-red-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <svg width="10" height="10" viewBox="0 0 10 10" fill="none"><path d="M2.5 2.5L7.5 7.5M7.5 2.5L2.5 7.5" stroke="#EF4444" strokeWidth="1.2" strokeLinecap="round" /></svg>
                  </span>
                  {item}
                </div>
              ))}
            </div>
          </section>

          {/* AI limitations */}
          <section>
            <h2 className="font-display text-2xl font-medium text-stone-900 mb-4">About AI-Assisted Features</h2>
            <div className="alert-warning">
              <p className="font-semibold mb-2">Important note about AI features:</p>
              <p className="text-sm leading-relaxed">
                Future versions of MindGuard will include optional AI-assisted reflection and thought reframing support. This AI is strictly limited to wellness support, journaling prompts, and general reflection guidance.
              </p>
              <ul className="mt-3 space-y-1.5 text-sm">
                <li>• The AI cannot and will not diagnose mental health conditions</li>
                <li>• The AI cannot provide medical or psychiatric advice</li>
                <li>• The AI is not a therapist and will not act as one</li>
                <li>• The AI will always redirect users in crisis to professional help</li>
                <li>• AI suggestions are general wellness guidance, not personalized clinical recommendations</li>
              </ul>
            </div>
          </section>

          {/* When to seek help */}
          <section>
            <h2 className="font-display text-2xl font-medium text-stone-900 mb-4">When to Seek Professional Help</h2>
            <p className="text-stone-600 leading-relaxed mb-4">
              MindGuard is designed for general wellness support. If you are experiencing any of the following, please reach out to a licensed mental health professional or emergency service:
            </p>
            <div className="bg-stone-50 border border-stone-200 rounded-xl p-5 space-y-2">
              {[
                'Thoughts of suicide or self-harm',
                'Feeling unable to care for yourself or others',
                'Persistent severe depression or anxiety interfering with daily life',
                'Substance abuse or addiction concerns',
                'Eating disorder symptoms',
                'Psychotic episodes or breaks from reality',
                'Domestic violence or abuse situations',
                'Any situation that feels like an emergency',
              ].map(item => (
                <div key={item} className="flex items-start gap-2.5 text-sm text-stone-700">
                  <span className="text-red-400 font-bold mt-0.5 flex-shrink-0">→</span>
                  {item}
                </div>
              ))}
            </div>
          </section>

          {/* Crisis resources */}
          <section>
            <h2 className="font-display text-2xl font-medium text-stone-900 mb-4">Crisis Resources (US)</h2>
            <div className="space-y-3">
              {[
                { name: '988 Suicide & Crisis Lifeline', contact: 'Call or text 988', url: 'https://988lifeline.org' },
                { name: 'Crisis Text Line', contact: 'Text HOME to 741741', url: 'https://www.crisistextline.org' },
                { name: 'NAMI Helpline', contact: '1-800-950-6264', url: 'https://www.nami.org/help' },
                { name: 'SAMHSA National Helpline', contact: '1-800-662-4357', url: 'https://www.samhsa.gov/find-help/national-helpline' },
                { name: 'Emergency Services', contact: 'Call 911', url: null },
              ].map(r => (
                <div key={r.name} className="card p-4 flex items-center justify-between gap-4">
                  <div>
                    <p className="text-sm font-semibold text-stone-800">{r.name}</p>
                    <p className="text-sm text-stone-500">{r.contact}</p>
                  </div>
                  {r.url && (
                    <a href={r.url} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-500 hover:underline flex-shrink-0">
                      Visit →
                    </a>
                  )}
                </div>
              ))}
            </div>
            <p className="mt-4 text-xs text-stone-400">
              International resources:{' '}
              <a href="https://www.findahelpline.com" target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">
                findahelpline.com
              </a>
            </p>
          </section>
        </div>
      </div>
    </div>
  )
}

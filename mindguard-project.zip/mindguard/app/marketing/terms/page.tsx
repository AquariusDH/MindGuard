import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Terms of Use',
  description: 'Read the MindGuard Terms of Use.',
}

export default function TermsPage() {
  const lastUpdated = 'January 1, 2025'

  return (
    <div className="py-20 px-6">
      <div className="max-w-2xl mx-auto">
        <div className="mb-12">
          <p className="section-label">Legal</p>
          <h1 className="font-display text-4xl font-medium text-stone-900 tracking-tight mb-4">
            Terms of Use
          </h1>
          <p className="text-sm text-stone-400">Last updated: {lastUpdated}</p>
        </div>

        <div className="alert-warning mb-8">
          <strong>Important:</strong> MindGuard is a wellness support tool — not a medical service, therapy platform, or crisis resource. By using MindGuard, you acknowledge and accept this.
        </div>

        <div className="space-y-8 text-sm leading-relaxed text-stone-600">
          {[
            {
              title: '1. Acceptance of Terms',
              body: 'By creating an account or using MindGuard, you agree to these Terms of Use. If you do not agree, please do not use the service.',
            },
            {
              title: '2. What MindGuard Is',
              body: 'MindGuard is a private wellness support platform designed to help individuals track their emotional state, practice thought reframing, and build self-reflection habits. It is not a licensed mental health service, therapy platform, medical platform, or emergency service.',
            },
            {
              title: '3. What MindGuard Is Not',
              body: 'MindGuard is expressly NOT: a substitute for professional therapy or counseling, a medical device or medical service, a crisis intervention service, a diagnostic tool for mental health conditions, or a replacement for emergency services. If you are in crisis, please call 988 or 911 immediately.',
            },
            {
              title: '4. Eligibility',
              body: 'You must be at least 18 years old to use MindGuard. By creating an account, you represent that you are 18 or older. If you are under 18, please do not use this service.',
            },
            {
              title: '5. User Accounts',
              body: 'You are responsible for maintaining the confidentiality of your account credentials. You are responsible for all activity that occurs under your account. Notify us immediately if you believe your account has been compromised.',
            },
            {
              title: '6. User Content',
              body: 'You retain ownership of all content you enter into MindGuard (check-ins, notes, reframes, reflections). By using the service, you grant MindGuard a limited license to store and display this content back to you within the platform. We do not sell or share your content with third parties. See our Privacy Policy for details.',
            },
            {
              title: '7. Prohibited Uses',
              body: 'You agree not to: use MindGuard for any unlawful purpose, attempt to access other users\' data, reverse engineer or scrape the platform, use MindGuard as a substitute for emergency services, or misrepresent that MindGuard is a licensed clinical service.',
            },
            {
              title: '8. Disclaimer of Warranties',
              body: 'MindGuard is provided "as is" without warranties of any kind. We do not warrant that the service will be uninterrupted, error-free, or that any particular wellness outcome will result from using it. Wellness practices vary significantly by individual.',
            },
            {
              title: '9. Limitation of Liability',
              body: 'To the fullest extent permitted by law, MindGuard shall not be liable for any indirect, incidental, special, consequential, or punitive damages arising from your use of the service. Our total liability shall not exceed the amount you paid us in the 12 months preceding the claim.',
            },
            {
              title: '10. Mental Health Disclaimer',
              body: 'MindGuard is not a mental health treatment provider. Nothing in MindGuard should be interpreted as professional mental health advice. If you are experiencing a mental health crisis, suicidal thoughts, or any situation requiring immediate help, please call 988 (Suicide & Crisis Lifeline) or 911.',
            },
            {
              title: '11. Changes to Terms',
              body: 'We may update these Terms from time to time. Material changes will be communicated via email. Continued use of MindGuard after changes constitutes acceptance of the new terms.',
            },
            {
              title: '12. Governing Law',
              body: 'These Terms are governed by the laws of the State of [Your State], without regard to conflict of law principles.',
            },
            {
              title: '13. Contact',
              body: 'Questions about these Terms? Contact us at legal@mindguard.app',
            },
          ].map(section => (
            <section key={section.title}>
              <h2 className="font-display text-lg font-medium text-stone-900 mb-2">{section.title}</h2>
              <p>{section.body}</p>
            </section>
          ))}
        </div>
      </div>
    </div>
  )
}

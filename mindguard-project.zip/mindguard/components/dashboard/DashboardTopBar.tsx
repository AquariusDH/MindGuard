'use client'

import { useState } from 'react'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { Logo } from '@/components/icons/Logo'
import { createClient } from '@/lib/supabase/client'
import { cn } from '@/lib/utils'

const PAGE_TITLES: Record<string, string> = {
  '/dashboard': 'Dashboard',
  '/dashboard/check-in': 'Daily Check-In',
  '/dashboard/reframe': 'Thought Reframe',
  '/dashboard/reflection': 'Weekly Reflection',
  '/dashboard/history': 'History',
  '/dashboard/insights': 'Insights',
  '/dashboard/settings': 'Settings',
  '/dashboard/crisis-support': 'Crisis Support',
  '/dashboard/ai-support': 'AI Support',
}

interface DashboardTopBarProps {
  displayName: string
}

export function DashboardTopBar({ displayName }: DashboardTopBarProps) {
  const pathname = usePathname()
  const router = useRouter()
  const [menuOpen, setMenuOpen] = useState(false)

  const title = PAGE_TITLES[pathname] ?? 'MindGuard'

  const handleLogout = async () => {
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push('/')
    router.refresh()
  }

  return (
    <header className="md:hidden bg-white border-b border-stone-200 px-4 h-14 flex items-center justify-between flex-shrink-0">
      <Link href="/">
        <Logo size="sm" />
      </Link>

      <span className="text-sm font-semibold text-stone-700 absolute left-1/2 -translate-x-1/2">
        {title}
      </span>

      <button
        className="p-2 rounded-lg text-stone-500 hover:bg-stone-100 transition-colors"
        onClick={() => setMenuOpen(!menuOpen)}
        aria-label="Menu"
      >
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          {menuOpen ? (
            <path d="M4 4L16 16M16 4L4 16" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          ) : (
            <path d="M3 6H17M3 10H17M3 14H17" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          )}
        </svg>
      </button>

      {/* Mobile dropdown */}
      {menuOpen && (
        <div className="absolute top-14 left-0 right-0 bg-white border-b border-stone-200 z-50 shadow-md px-4 py-3 space-y-1">
          {[
            { href: '/dashboard', label: 'Dashboard' },
            { href: '/dashboard/check-in', label: 'Daily Check-In' },
            { href: '/dashboard/reframe', label: 'Thought Reframe' },
            { href: '/dashboard/reflection', label: 'Weekly Reflection' },
            { href: '/dashboard/history', label: 'History' },
            { href: '/dashboard/insights', label: 'Insights' },
            { href: '/dashboard/settings', label: 'Settings' },
            { href: '/dashboard/crisis-support', label: 'Crisis Support' },
          ].map(item => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'block px-3 py-2.5 rounded-lg text-sm font-medium transition-colors',
                pathname === item.href
                  ? 'bg-blue-50 text-blue-600'
                  : 'text-stone-600 hover:bg-stone-50'
              )}
              onClick={() => setMenuOpen(false)}
            >
              {item.label}
            </Link>
          ))}
          <div className="border-t border-stone-100 pt-2 mt-2">
            <button
              onClick={handleLogout}
              className="w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium text-stone-500 hover:bg-stone-50"
            >
              Log out
            </button>
          </div>
        </div>
      )}
    </header>
  )
}

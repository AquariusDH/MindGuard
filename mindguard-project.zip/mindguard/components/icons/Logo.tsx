import { cn } from '@/lib/utils'

interface LogoMarkProps {
  size?: number
  className?: string
}

export function LogoMark({ size = 32, className }: LogoMarkProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="shield-grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#3A7DC9" />
          <stop offset="100%" stopColor="#3D9B4A" />
        </linearGradient>
      </defs>
      {/* Shield body */}
      <path
        d="M16 3L5 7.5V15C5 21.1 9.8 26.7 16 28.5C22.2 26.7 27 21.1 27 15V7.5L16 3Z"
        fill="url(#shield-grad)"
      />
      {/* Checkmark */}
      <path
        d="M11 16L14.5 19.5L21 12.5"
        stroke="white"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

interface LogoProps {
  size?: 'sm' | 'md' | 'lg'
  className?: string
  textClassName?: string
}

export function Logo({ size = 'md', className, textClassName }: LogoProps) {
  const sizes = {
    sm: { mark: 24, text: 'text-base' },
    md: { mark: 32, text: 'text-xl' },
    lg: { mark: 40, text: 'text-2xl' },
  }

  const { mark, text } = sizes[size]

  return (
    <div className={cn('flex items-center gap-2.5', className)}>
      <LogoMark size={mark} />
      <span
        className={cn(
          'font-display font-semibold text-stone-900 tracking-tight',
          text,
          textClassName
        )}
      >
        MindGuard
      </span>
    </div>
  )
}

// For use on dark backgrounds
export function LogoLight({ size = 'md', className }: LogoProps) {
  const sizes = {
    sm: { mark: 24, text: 'text-base' },
    md: { mark: 32, text: 'text-xl' },
    lg: { mark: 40, text: 'text-2xl' },
  }

  const { mark, text } = sizes[size]

  return (
    <div className={cn('flex items-center gap-2.5', className)}>
      <LogoMark size={mark} />
      <span
        className={cn(
          'font-display font-semibold text-white tracking-tight',
          text
        )}
      >
        MindGuard
      </span>
    </div>
  )
}

export default Logo

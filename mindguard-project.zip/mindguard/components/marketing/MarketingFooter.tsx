import Link from 'next/link'
import { LogoLight } from '@/components/icons/Logo'

const FOOTER_LINKS = {
  Product: [
    { href: '/how-it-works', label: 'How It Works' },
    { href: '/pricing', label: 'Pricing' },
    { href: '/about', label: 'About' },
  ],
  Support: [
    { href: '/safety', label: 'Safety' },
    { href: '/contact', label: 'Contact' },
    { href: '/dashboard/crisis-support', label: 'Crisis Support' },
  ],
  Legal: [
    { href: '/privacy', label: 'Privacy Policy' },
    { href: '/terms', label: 'Terms of Use' },
  ],
}

export function MarketingFooter() {
  return (
    <footer className="bg-stone-900 text-white">
      {/* Disclaimer banner */}
      <div className="border-b border-white/10 px-6 py-4 text-center text-xs text-white/50 max-w-3xl mx-auto">
        MindGuard is a wellness support tool — not a licensed mental health service, therapy platform, or emergency resource.
        If you are in crisis, call or text{' '}
        <a href="tel:988" className="text-white/70 font-semibold underline">988</a>{' '}
        (Suicide &amp; Crisis Lifeline) or visit{' '}
        <a href="https://988lifeline.org" target="_blank" rel="noopener noreferrer" className="text-white/70 underline">
          988lifeline.org
        </a>.
      </div>

      <div className="max-w-6xl mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="md:col-span-1">
            <Link href="/">
              <LogoLight size="sm" />
            </Link>
            <p className="mt-4 text-sm text-white/40 leading-relaxed max-w-52">
              A private space to understand yourself better. One check-in at a time.
            </p>
          </div>

          {/* Links */}
          {Object.entries(FOOTER_LINKS).map(([group, links]) => (
            <div key={group}>
              <h3 className="text-xs font-bold tracking-widest uppercase text-white/30 mb-4">
                {group}
              </h3>
              <ul className="space-y-2.5">
                {links.map(({ href, label }) => (
                  <li key={href}>
                    <Link
                      href={href}
                      className="text-sm text-white/50 hover:text-white/90 transition-colors duration-150"
                    >
                      {label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom bar */}
        <div className="mt-16 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-white/30">
            © {new Date().getFullYear()} MindGuard. All rights reserved.
          </p>
          <div className="flex items-center gap-2 text-xs text-white/30">
            <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-pulse" />
            Crisis? Call or text{' '}
            <a href="tel:988" className="font-bold text-white/60 hover:text-white transition-colors">
              988
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}

'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Logo } from '@/components/icons/Logo'
import { cn } from '@/lib/utils'
import { analytics } from '@/lib/analytics/events'

const NAV_LINKS = [
  { href: '/how-it-works', label: 'How It Works' },
  { href: '/about', label: 'About' },
  { href: '/pricing', label: 'Pricing' },
  { href: '/safety', label: 'Safety' },
]

export function MarketingNav() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const pathname = usePathname()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    setMobileOpen(false)
  }, [pathname])

  return (
    <>
      {/* Crisis strip */}
      <div className="bg-red-50 border-b border-red-100 py-2 px-6 text-center text-xs text-red-700">
        MindGuard is not a crisis service. If you&rsquo;re in immediate danger, call{' '}
        <a href="tel:988" className="font-semibold underline">988</a> or{' '}
        <a href="tel:911" className="font-semibold underline">911</a>.{' '}
        <Link href="/dashboard/crisis-support" className="underline">
          Crisis resources →
        </Link>
      </div>

      <nav
        className={cn(
          'sticky top-0 z-50 transition-all duration-300',
          scrolled
            ? 'bg-white/95 backdrop-blur-md border-b border-stone-200 shadow-sm'
            : 'bg-white/80 backdrop-blur-sm border-b border-transparent'
        )}
      >
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          {/* Logo */}
          <Link href="/" aria-label="MindGuard home">
            <Logo size="sm" />
          </Link>

          {/* Desktop links */}
          <ul className="hidden md:flex items-center gap-1">
            {NAV_LINKS.map(({ href, label }) => (
              <li key={href}>
                <Link
                  href={href}
                  className={cn(
                    'px-3 py-2 rounded-lg text-sm font-medium transition-colors duration-150',
                    pathname === href
                      ? 'text-blue-600 bg-blue-50'
                      : 'text-stone-500 hover:text-stone-900 hover:bg-stone-100'
                  )}
                >
                  {label}
                </Link>
              </li>
            ))}
          </ul>

          {/* Desktop CTA */}
          <div className="hidden md:flex items-center gap-3">
            <Link href="/login" className="btn-ghost text-sm">
              Log in
            </Link>
            <Link
              href="/signup"
              className="btn-primary text-sm"
              onClick={() => analytics.ctaClick('nav')}
            >
              Start Free
            </Link>
          </div>

          {/* Mobile menu button */}
          <button
            className="md:hidden p-2 rounded-lg text-stone-500 hover:bg-stone-100 transition-colors"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={mobileOpen}
          >
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
              {mobileOpen ? (
                <path d="M4 4L16 16M16 4L4 16" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
              ) : (
                <path d="M3 6H17M3 10H17M3 14H17" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
              )}
            </svg>
          </button>
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="md:hidden border-t border-stone-100 bg-white px-6 py-4 space-y-1">
            {NAV_LINKS.map(({ href, label }) => (
              <Link
                key={href}
                href={href}
                className={cn(
                  'block px-3 py-2.5 rounded-lg text-sm font-medium transition-colors',
                  pathname === href
                    ? 'text-blue-600 bg-blue-50'
                    : 'text-stone-600 hover:bg-stone-50'
                )}
              >
                {label}
              </Link>
            ))}
            <div className="pt-3 border-t border-stone-100 mt-3 flex flex-col gap-2">
              <Link href="/login" className="btn-secondary text-sm w-full justify-center">
                Log in
              </Link>
              <Link
                href="/signup"
                className="btn-primary text-sm w-full justify-center"
                onClick={() => analytics.ctaClick('nav-mobile')}
              >
                Start Free
              </Link>
            </div>
          </div>
        )}
      </nav>
    </>
  )
}

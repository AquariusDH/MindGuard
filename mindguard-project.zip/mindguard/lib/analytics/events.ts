'use client'

// MindGuard Analytics
// Uses Plausible Analytics (privacy-first, GDPR-compliant)
// All events are non-PII and aggregate only

declare global {
  interface Window {
    plausible?: (event: string, options?: { props?: Record<string, string | number | boolean> }) => void
  }
}

// Core tracking function - gracefully no-ops if Plausible not loaded
function track(event: string, props?: Record<string, string | number | boolean>) {
  if (typeof window !== 'undefined' && window.plausible) {
    window.plausible(event, { props })
  }
  // Dev logging
  if (process.env.NODE_ENV === 'development') {
    console.log('[Analytics]', event, props)
  }
}

// ============================================================
// ACQUISITION EVENTS
// ============================================================

export const analytics = {
  // Marketing / acquisition
  ctaClick: (location: string) =>
    track('CTA Click', { location }),

  pricingView: () =>
    track('Pricing Page View'),

  howItWorksView: () =>
    track('How It Works View'),

  // Auth
  signupStarted: () =>
    track('Signup Started'),

  signupCompleted: () =>
    track('Signup Completed'),

  loginCompleted: () =>
    track('Login Completed'),

  // Onboarding
  firstCheckinStarted: () =>
    track('First Checkin Started'),

  firstCheckinCompleted: () =>
    track('First Checkin Completed'),

  // Core feature usage
  checkinCompleted: (moodScore: number) =>
    track('Checkin Completed', { mood_score: moodScore }),

  reframeStarted: () =>
    track('Reframe Started'),

  reframeCompleted: (aiAssisted: boolean) =>
    track('Reframe Completed', { ai_assisted: aiAssisted }),

  reflectionCompleted: () =>
    track('Weekly Reflection Completed'),

  historyViewed: () =>
    track('History Viewed'),

  insightsViewed: () =>
    track('Insights Viewed'),

  // Engagement
  badgeEarned: (badgeSlug: string) =>
    track('Badge Earned', { badge: badgeSlug }),

  streakAchieved: (days: number) =>
    track('Streak Achieved', { days }),

  // Feedback / support
  feedbackSubmitted: (type: string) =>
    track('Feedback Submitted', { type }),

  crisisPageViewed: () =>
    track('Crisis Page Viewed'),

  // Settings
  settingsUpdated: () =>
    track('Settings Updated'),
}

// ============================================================
// KPI REFERENCE (for dashboards)
// ============================================================

/*
Recommended KPIs to monitor in Plausible dashboard:

ACQUISITION:
- Unique visitors (weekly/monthly)
- Signup Completed rate (signups / visitors)
- CTA Click by location (hero, pricing, how-it-works)
- Traffic sources (organic, direct, referral)

ACTIVATION:
- First Checkin Completed (within 24h of signup)
- First Reframe Completed (within 7 days)

RETENTION:
- D7 retention (users returning within 7 days)
- D30 retention
- Checkin Completed events per user per month
- 7-Day Streak Achieved

ENGAGEMENT:
- Reframe Completed / Checkin Completed ratio
- Weekly Reflection Completed rate
- Average session duration (via Plausible)

PRODUCT HEALTH:
- Feedback Submitted rate
- Crisis Page Viewed (monitor for support needs)
- Pricing Page View → Signup conversion

EARLY WARNING:
- Drop-off after signup (no First Checkin Completed)
- Crisis Page spikes (may indicate product/copy issue)
*/

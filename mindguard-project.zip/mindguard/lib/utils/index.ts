import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'
import { format, startOfWeek, addDays, parseISO, differenceInDays } from 'date-fns'

// Tailwind class merging
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// ============================================================
// DATE UTILITIES
// ============================================================

// Get today's date as YYYY-MM-DD in local timezone
export function todayString(): string {
  const now = new Date()
  return format(now, 'yyyy-MM-dd')
}

// Get the Monday of the current week
export function currentWeekStart(): string {
  const now = new Date()
  const monday = startOfWeek(now, { weekStartsOn: 1 })
  return format(monday, 'yyyy-MM-dd')
}

// Format a date string for display
export function formatDate(dateStr: string, pattern = 'MMM d, yyyy'): string {
  try {
    return format(parseISO(dateStr), pattern)
  } catch {
    return dateStr
  }
}

// Format a timestamp for display
export function formatDateTime(timestamp: string): string {
  try {
    return format(parseISO(timestamp), 'MMM d, yyyy · h:mm a')
  } catch {
    return timestamp
  }
}

// Human-readable relative date (Today, Yesterday, etc)
export function relativeDate(dateStr: string): string {
  try {
    const date = parseISO(dateStr)
    const today = new Date()
    const diff = differenceInDays(today, date)

    if (diff === 0) return 'Today'
    if (diff === 1) return 'Yesterday'
    if (diff < 7) return `${diff} days ago`
    return format(date, 'MMM d')
  } catch {
    return dateStr
  }
}

// Get week label for display
export function weekLabel(weekStart: string): string {
  try {
    const start = parseISO(weekStart)
    const end = addDays(start, 6)
    return `${format(start, 'MMM d')} – ${format(end, 'MMM d, yyyy')}`
  } catch {
    return weekStart
  }
}

// ============================================================
// FORMATTING UTILITIES
// ============================================================

// Format mood score to label
export function moodLabel(score: number): string {
  const labels: Record<number, string> = {
    1: 'Very Low',
    2: 'Low',
    3: 'Neutral',
    4: 'Good',
    5: 'Great',
  }
  return labels[score] ?? 'Unknown'
}

// Format mood score to emoji
export function moodEmoji(score: number): string {
  const emojis: Record<number, string> = {
    1: '😞',
    2: '😟',
    3: '😐',
    4: '🙂',
    5: '😊',
  }
  return emojis[score] ?? '😐'
}

// Format sleep hours
export function formatSleep(hours: number): string {
  if (hours === 1) return '1 hour'
  if (Number.isInteger(hours)) return `${hours} hours`
  return `${hours} hours`
}

// Truncate text
export function truncate(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text
  return text.slice(0, maxLength - 3) + '...'
}

// ============================================================
// STREAK CALCULATION
// ============================================================

// Calculate current streak from array of date strings (sorted desc)
export function calculateStreak(dates: string[]): number {
  if (!dates.length) return 0

  const today = todayString()
  const sortedDates = [...new Set(dates)].sort().reverse()

  // Check if there's a check-in today or yesterday (allow 1-day gap)
  const mostRecent = sortedDates[0]
  const gapFromToday = differenceInDays(parseISO(today), parseISO(mostRecent))

  if (gapFromToday > 1) return 0

  let streak = 1
  for (let i = 1; i < sortedDates.length; i++) {
    const current = parseISO(sortedDates[i])
    const previous = parseISO(sortedDates[i - 1])
    const gap = differenceInDays(previous, current)

    if (gap === 1) {
      streak++
    } else {
      break
    }
  }

  return streak
}

// ============================================================
// BADGE CHECKING UTILITIES
// ============================================================

export function shouldAwardBadge(
  existingBadges: string[],
  badge: string,
  condition: boolean
): boolean {
  return condition && !existingBadges.includes(badge)
}

// ============================================================
// MISC
// ============================================================

// Get user initials from display name
export function getInitials(name: string | null): string {
  if (!name) return 'MG'
  return name
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2)
}

// Average from array of numbers
export function average(nums: number[]): number | null {
  if (!nums.length) return null
  return Math.round((nums.reduce((a, b) => a + b, 0) / nums.length) * 10) / 10
}

// Safe JSON parse
export function safeParseJson<T>(str: string, fallback: T): T {
  try {
    return JSON.parse(str) as T
  } catch {
    return fallback
  }
}

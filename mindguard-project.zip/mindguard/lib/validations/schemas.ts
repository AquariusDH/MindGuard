import { z } from 'zod'

// Auth
export const loginSchema = z.object({
  email: z.string().email('Please enter a valid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
})

export const signupSchema = z.object({
  email: z.string().email('Please enter a valid email address'),
  password: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .regex(/[A-Z]/, 'Include at least one uppercase letter')
    .regex(/[0-9]/, 'Include at least one number'),
  confirmPassword: z.string(),
  displayName: z
    .string()
    .min(2, 'Name must be at least 2 characters')
    .max(50, 'Name is too long')
    .optional(),
  agreeToTerms: z.literal(true, {
    errorMap: () => ({ message: 'You must agree to the terms of use' }),
  }),
}).refine(data => data.password === data.confirmPassword, {
  message: 'Passwords do not match',
  path: ['confirmPassword'],
})

export const forgotPasswordSchema = z.object({
  email: z.string().email('Please enter a valid email address'),
})

// Daily Check-In
export const checkinSchema = z.object({
  mood_score: z
    .number()
    .int()
    .min(1, 'Please select a mood')
    .max(5),
  anxiety_level: z
    .number()
    .int()
    .min(1)
    .max(10),
  sleep_hours: z
    .number()
    .min(0)
    .max(18)
    .multipleOf(0.5),
  gratitude_note: z
    .string()
    .max(500, 'Keep it under 500 characters')
    .optional()
    .transform(v => v || null),
  general_notes: z
    .string()
    .max(1000, 'Keep it under 1000 characters')
    .optional()
    .transform(v => v || null),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Invalid date format'),
})

// Thought Reframe
export const reframeSchema = z.object({
  negative_thought: z
    .string()
    .min(5, 'Please describe the thought in more detail')
    .max(1000, 'Keep it under 1000 characters'),
  intensity_level: z
    .number()
    .int()
    .min(1)
    .max(10),
  emotion_tags: z
    .array(z.string())
    .max(5, 'Select up to 5 emotions'),
  context_note: z
    .string()
    .max(500, 'Keep it under 500 characters')
    .optional()
    .transform(v => v || null),
  reframed_thought: z
    .string()
    .max(1000, 'Keep it under 1000 characters')
    .optional()
    .transform(v => v || null),
})

// Weekly Reflection
export const reflectionSchema = z.object({
  week_start: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Invalid date format'),
  biggest_challenge: z
    .string()
    .max(1000, 'Keep it under 1000 characters')
    .optional()
    .transform(v => v || null),
  biggest_win: z
    .string()
    .max(1000, 'Keep it under 1000 characters')
    .optional()
    .transform(v => v || null),
  next_week_goal: z
    .string()
    .max(500, 'Keep it under 500 characters')
    .optional()
    .transform(v => v || null),
})

// Feedback
export const feedbackSchema = z.object({
  feedback_type: z.enum(['bug', 'feature', 'general']),
  message: z
    .string()
    .min(10, 'Please share a bit more detail')
    .max(2000, 'Please keep feedback under 2000 characters'),
  email: z
    .string()
    .email('Please enter a valid email')
    .optional()
    .or(z.literal(''))
    .transform(v => v || null),
})

// Profile settings
export const profileSchema = z.object({
  display_name: z
    .string()
    .min(2, 'Name must be at least 2 characters')
    .max(50, 'Name is too long'),
  timezone: z.string(),
})

// Contact form
export const contactSchema = z.object({
  name: z.string().min(2, 'Please enter your name'),
  email: z.string().email('Please enter a valid email'),
  message: z
    .string()
    .min(20, 'Please share more detail')
    .max(2000, 'Please keep message under 2000 characters'),
})

// Type exports
export type LoginInput = z.infer<typeof loginSchema>
export type SignupInput = z.infer<typeof signupSchema>
export type ForgotPasswordInput = z.infer<typeof forgotPasswordSchema>
export type CheckinInput = z.infer<typeof checkinSchema>
export type ReframeInput = z.infer<typeof reframeSchema>
export type ReflectionInput = z.infer<typeof reflectionSchema>
export type FeedbackInput = z.infer<typeof feedbackSchema>
export type ProfileInput = z.infer<typeof profileSchema>
export type ContactInput = z.infer<typeof contactSchema>

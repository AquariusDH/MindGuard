import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        // Brand Blues — trust, clarity, calm
        blue: {
          50: '#EEF4FB',
          100: '#C8DEFA',
          200: '#A4C6F5',
          300: '#6FA5D8',
          400: '#4D8EC9',
          500: '#3A7DC9',
          600: '#2560A8',
          700: '#1A4A85',
          800: '#143556',
          900: '#0C2238',
        },
        // Brand Greens — healing, growth, gratitude
        green: {
          50: '#EDF5EF',
          100: '#C5E0C9',
          200: '#9FCAA5',
          300: '#72B87C',
          400: '#52A85C',
          500: '#3D9B4A',
          600: '#2B7835',
          700: '#1E5E27',
          800: '#134519',
          900: '#0B2D10',
        },
        // Sage — backgrounds, cards, neutral warmth
        sage: {
          50: '#F5F7F5',
          100: '#E3EAE4',
          200: '#C8D5CA',
          300: '#A8BEA9',
        },
        // Warm stone neutrals
        stone: {
          50: '#FAFAF9',
          100: '#F2F1EF',
          200: '#E4E3DF',
          300: '#CBC9C4',
          400: '#A8A7A3',
          500: '#87857F',
          600: '#6B6A67',
          700: '#504F4C',
          800: '#2E2D2B',
          900: '#1A1917',
        },
      },
      fontFamily: {
        display: ['Playfair Display', 'Georgia', 'serif'],
        body: ['DM Sans', 'system-ui', 'sans-serif'],
        sans: ['DM Sans', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        'display-2xl': ['3.75rem', { lineHeight: '1.1', letterSpacing: '-0.03em' }],
        'display-xl': ['3rem', { lineHeight: '1.1', letterSpacing: '-0.03em' }],
        'display-lg': ['2.5rem', { lineHeight: '1.15', letterSpacing: '-0.025em' }],
        'display-md': ['2rem', { lineHeight: '1.2', letterSpacing: '-0.02em' }],
        'display-sm': ['1.5rem', { lineHeight: '1.25', letterSpacing: '-0.015em' }],
      },
      borderRadius: {
        'sm': '6px',
        'md': '10px',
        'lg': '14px',
        'xl': '20px',
        '2xl': '28px',
        '3xl': '36px',
      },
      boxShadow: {
        'xs': '0 1px 2px rgba(0,0,0,0.05)',
        'sm': '0 1px 4px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04)',
        'md': '0 4px 16px rgba(0,0,0,0.08), 0 2px 6px rgba(0,0,0,0.04)',
        'lg': '0 10px 40px rgba(0,0,0,0.10), 0 4px 12px rgba(0,0,0,0.05)',
        'xl': '0 20px 60px rgba(0,0,0,0.12), 0 8px 20px rgba(0,0,0,0.06)',
        'blue': '0 4px 20px rgba(58,125,201,0.25)',
        'blue-lg': '0 8px 32px rgba(58,125,201,0.30)',
      },
      spacing: {
        '18': '4.5rem',
        '22': '5.5rem',
        '26': '6.5rem',
        '30': '7.5rem',
      },
      animation: {
        'fade-up': 'fadeUp 0.6s ease forwards',
        'fade-in': 'fadeIn 0.4s ease forwards',
        'pulse-dot': 'pulseDot 2s ease-in-out infinite',
        'slide-in-right': 'slideInRight 0.3s ease forwards',
      },
      keyframes: {
        fadeUp: {
          '0%': { opacity: '0', transform: 'translateY(20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        pulseDot: {
          '0%, 100%': { opacity: '1', transform: 'scale(1)' },
          '50%': { opacity: '0.5', transform: 'scale(0.8)' },
        },
        slideInRight: {
          '0%': { opacity: '0', transform: 'translateX(16px)' },
          '100%': { opacity: '1', transform: 'translateX(0)' },
        },
      },
    },
  },
  plugins: [],
}

export default config
